import { LightningElement, track, wire, api } from 'lwc';
// Import custom labels
import loqateKey from '@salesforce/label/c.Loqate_key';

export default class Ei_NI_AddressFinder extends LightningElement {

    @api searchAddressStr = '';                 // To store the text entered to find the respective addresses
    @api addresslabel = '';                     // To store the label of the sub address to pass it for the event to parent component
    @api houseNo ;                        // To store the house of the address
    @api streetName ;
    @api townCity ;                       // To store the town or city of the address
    @api county ;                         // To store the county of the address
    @api postCode ;                       // To store the postcode of the address
    @api country ;                        // To store the country of the address
    @track localAuthorityArea = '';
    @track addressResponseList = [];            // To get the response of the addresses data from the api call
    @track childAddressResponseList = [];       // To get the response of the child addresses data from the api call
    @track addressType = '';                    // To get the addresses type either Parent addresses or Child addresses
    @track selectedAddressStr = '';             // To get the current selected address from the dropdown address picklist
    @track fullAddressForHtml = '';     
    label = {  loqateKey  };                    // To store all the custom label in an object          

    @track isManualAddress = false;             // To store if the user wants to enter the address manually
    @track showAddresses = false;               // To store if the user wants to enter the address manually
    @track isHouse = false;
    @track showSelectedAddresses = true;        // To show the current selected address div on the HTML


    constructor() {
        super();
        // console.log('Child constructor');
    }

    connectedCallback() {
        // console.log('Line 62 -> Child Connected Callback START');
        // console.log('Line 87 -> Child Connected Callback END -> ');
    }

    renderedCallback() {
        // console.log('Line 62 -> Child Rendered Callback START');
        // console.log('Line 87 -> Child Rendered Callback END');
    }

    disconnectedCallback() {
        // console.log('Line 62 -> Child Disconnected Callback START');
        // console.log('Line 87 -> Child Disconnected Callback END');
    }

    get returnAddressResponseListSize() {
        return this.addressResponseList.length>0;
    }

    get isStreetPresent() {
        return this.streetName ? true : false;
    }

    get isTownCityPresent() {
        return this.townCity ? true : false;
    }

    get isCountyPresent() {
        return this.county ? true : false;
    }

    get isPostCodePresent() {
        return this.postCode ? true : false;
    }

    get isCountryPresent() {
        return this.country ? true : false;
    }

    enterAddressManually() {
        //this.showSelectedAddresses = false;
        
        this.isManualAddress=!this.isManualAddress;
        if(!this.isManualAddress) {
            this.showSelectedAddresses = true;
            // setTimeout(function() {
            //     //your code to be executed after 1 second
            //     let resBox = this.template.querySelector(".niManual");
            //     console.log('-->>'+this.fullAddressForHtml);
            //     console.log('-->>'+resBox);
            //     resBox.innerHTML = this.fullAddressForHtml;
            // }, 5000);

        } else {
            this.showSelectedAddresses = false;
        }
        
    }

    handleLiClick(event) {
        console.log('Line 92 weird -->>');
    }
    
    eventManualAddressHandler(event) {
        console.log('Line 48 -> ',event.target.name);
        // If event takes place due to input of street
        if(event.target.name.includes("Street")) {
            // this.streetName = [this.template.querySelector("lightning-textarea").value];

            this.streetName = this.template.querySelector("lightning-textarea").value;
            console.log('Line 100 -> ',this.streetName);
            console.log('Line 100 -> ',typeof this.streetName);
            // Calling parent using Event with data START
            const myEvent = new CustomEvent('fieldchange', {
                detail: {
                    addressType: this.addresslabel,
                    fieldName: event.target.name,
                    value: this.streetName
                }
            });
            this.dispatchEvent(myEvent);
            // Calling parent using Event with data END

        } else {
            if(event.target.name.includes("City")) {
                this.townCity = this.template.querySelector("[name='inputTownCity']").value;
                
            } else if(event.target.name.includes("County")) {
                this.county = this.template.querySelector("[name='inputCounty']").value;
                
            } else if(event.target.name.includes("Postcode")) {
                this.postCode = this.template.querySelector("[name='inputPostcode']").value;
                
            } else if(event.target.name.includes("Country")) {
                this.country = this.template.querySelector("[name='inputCountry']").value;
            }

            // Calling parent using Event with data START
            const myEvent = new CustomEvent('fieldchange', {
                detail: {
                    addressType: this.addresslabel,
                    fieldName: event.target.name,
                    value: this.template.querySelector('[name="' +event.target.name+ '"]').value
                }
            });
            this.dispatchEvent(myEvent);
            // Calling parent using Event with data END
        }
        
    }

    addressChangeHandler(event) {
        this.searchAddressStr = this.template.querySelector('[name="inputAddress"]').value;
        let searchAddressStr = this.template.querySelector('[name="inputAddress"]').value;
        console.log('Line 15 -> ',searchAddressStr);
        console.log('Line 15 length -> ',searchAddressStr.length);

        if(searchAddressStr.length>2) {
            this.findAddress(event, this.searchAddressStr);

        } else if(event.keyCode === 13) {
            console.log('Line 16 -> On enter');
            this.findAddress(event, this.searchAddressStr);
            
        } else {
            this.addressResponseList = [];
            this.showAddresses = false;
            
            // const resBox = this.template.querySelector(".niManual");
            // resBox.innerHTML = '';
        }
    }

    demoTextarea() {
        console.log('Line 155 textarea -> ',this.streetName);
    }

    // First method of searching address via loqate
    findAddress(event, searchAddressStr, SecondFind) {
        //debugger;
        console.log('Line 67 finding address');
        //var Text = document.getElementById("searchBox2").value;
        var searchText = searchAddressStr;
        var availableopts = [];
        var myOrgBaseURL = window.location.origin;
        console.log('searchText -> '+searchText);

        if (searchText === "") {
            showError("Please enter an address");
            return;
        }

        var Container = "";	
        if (SecondFind !== undefined) {
            Container = SecondFind;
        } 
        
        var Key = this.label.loqateKey,    //Key = $A.get("$Label.c.Loqate_key"),
            IsMiddleware = false,
            Origin = "",
            Countries = "GBR",
            Limit = "10",
            Language = "en-gb",  
            url = 'https://services.postcodeanywhere.co.uk/Capture/Interactive/Find/v1.10/json3.ws';
        var params = '';
        params += "&Key=" + encodeURIComponent(Key);
        params += "&Text=" + encodeURIComponent(searchText);
        params += "&IsMiddleware=" + encodeURIComponent(IsMiddleware);
        params += "&Container=" + encodeURIComponent(Container);
        params += "&Origin=" + encodeURIComponent(Origin);
        params += "&Countries=" + encodeURIComponent(Countries);
        params += "&Limit=" + encodeURIComponent(Limit);
        params += "&Language=" + encodeURIComponent(Language);
        //params += "&Access-Control-Allow-Origin=" + "https://uat-thedisputeservice.cs87.force.com";
        params += "&Access-Control-Allow-Origin=" + myOrgBaseURL;
        
        var listOfResponse = [];
        var http = new XMLHttpRequest();
        http.open('POST', url, true);
        http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        //http.setRequestHeader('Access-Control-Allow-Origin', 'https://uat-thedisputeservice.cs87.force.com');
        http.setRequestHeader('Access-Control-Allow-Origin', myOrgBaseURL);
        http.onreadystatechange = () => {
            //console.log('@@http.status -->> '+http.status+url); 
            if(http.readyState == 4 && http.status == 200) {
                var response = JSON.parse(http.responseText);
                console.log('@@ response -> '+JSON.stringify(response));
                if (response.Items.length == 1 && typeof(response.Items[0].Error) != "undefined") {
                    showError(response.Items[0].Description);
                    this.showAddresses=false;
                }
                else {
                    if (response.Items.length == 0) {
                        showError("Sorry, there were no results");
                        //reject("Sorry, there were no results");

                    } else {
                        
                        console.log('Line 159 response -> ',response.Items.length);
                        console.log('Line 160 response -> ',JSON.stringify(response.Items[0]));

                        //console.log('Line 162 -> showAddresses -> ',this.showAddresses);
                        
                        

                        if(this.addressType==='Chlid Addresses') {
                            for(var i = 0; i < response.Items.length; i++) {
                                console.log('response 141 -> '+response.Items[i].Text);
                                console.log('response 142 -> '+response.Items[i].Description);
                                console.log('response 143 -> '+response.Items[i].Id);
                                console.log('response 144 -> '+response.Items[i].Type);
                                if(response.Items[i].length>1) {
                                    console.log('response 170 -> Child nodes present');
                                }
                                var responseDetail = {
                                    "text": response.Items[i].Text,
                                    "description": response.Items[i].Description,
                                    "Id": response.Items[i].Id,
                                    "type": response.Items[i].Type
                                }
                                
                                listOfResponse.push(responseDetail);
                                
                            }

                        } else {
                            for(var i = 0; i < response.Items.length; i++) {
                                console.log('response 141 -> '+response.Items[i].Text);
                                console.log('response 142 -> '+response.Items[i].Description);
                                console.log('response 143 -> '+response.Items[i].Id);
                                console.log('response 144 -> '+response.Items[i].Type);
                                if(response.Items[i].length>1) {
                                    console.log('response 170 -> Child nodes present');
                                }
                                var responseDetail = {
                                    "text": response.Items[i].Text,
                                    "description": response.Items[i].Description,
                                    "Id": response.Items[i].Id,
                                    "type": response.Items[i].Type
                                }
                                
                                listOfResponse.push(responseDetail);
                                
                            }
                        }
                        
                        console.log('Line 213 -> ',this.showAddresses);
                        this.showAddresses = true;                            // Showing the picklist of addresses on HTML
                        this.addressResponseList = listOfResponse;            // Initializing the picklist values of addresses
                        console.log('Line 215 -> ',JSON.stringify(this.addressResponseList));
                          
                        //this.selectAddress(event,searchText);
                    }
                }
            }
        };
        //http.onerror = () => reject(http.statusText);
        http.send(params);

        console.log('Line 222 -> ',lstTempResponse);

    }

    // Second method of searching address via loqate on span call
    handleAddressClick(event) {
        let currentSelectedAddressId = event.target.getAttribute('data-id');
        console.log('Line 297 currentSelectedAddressId -> ',currentSelectedAddressId);

        this.addressResponseList.forEach(currResponse => {
            if(currentSelectedAddressId==currResponse.Id) {
                console.log('Line 276 currResponse -> ',JSON.stringify(currResponse));
                if(currResponse.description.includes('Addresses')) {
                    this.addressType='Chlid Addresses';
                    this.findAddress(event, this.searchAddressStr, currentSelectedAddressId);

                } else {
                    console.log('Line 322 -> doesnt contains addresses');
                    this.retrieveAddress(event, currentSelectedAddressId);
                }
            }
        });
    }

    // Second method of searching address via loqate
    selectAddressHandler(event) {
        console.log('Line 226 -> ');
        var selectedAddress = this.template.querySelector("[name='selectAddress']");
        console.log('Line 228 selectedAddress -> ',selectedAddress.value);

        this.addressResponseList.forEach(currResponse => {
            if(selectedAddress.value==currResponse.Id) {
                console.log('Line 276 currResponse -> ',JSON.stringify(currResponse));
                if(currResponse.description.includes('Addresses')) {
                    console.log('Line 317 -> contains addresses');
                    this.addressType='Chlid Addresses';
                    this.findAddress(event, this.searchAddressStr, currResponse.Id);

                } else {
                    console.log('Line 322 -> doesnt contains addresses');
                    this.retrieveAddress(event, currResponse.Id);
                }
            }
        });

    }

    // Third method of searching address via loqate
    retrieveAddress(event, Id) {
        console.log(`Line 330 Key -> ${this.label.loqateKey} -> Id -> ${Id}`);
        var Field1Format = "";
        var url = 'https://services.postcodeanywhere.co.uk/Capture/Interactive/Retrieve/v1.00/json3.ws';
        var params = '';
        params += "&Key=" + encodeURIComponent(this.label.loqateKey);
        params += "&Id=" + encodeURIComponent(Id);
        params += "&Field1Format=" + encodeURIComponent(Field1Format);
        
        var http = new XMLHttpRequest();
        http.open('POST', url, true);
        http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        http.onreadystatechange = () => {
            if (http.readyState == 4 && http.status == 200) {
                var response = JSON.parse(http.responseText);
                
                if (response.Items.length == 1 && typeof(response.Items[0].Error) != "undefined") {
                    showError(response.Items[0].Description);
                    
                } else {
                    if (response.Items.length == 0)
                        showError("Sorry, there were no results");
                    else {  
                        console.log('Line 357 api call success');
                        var addressline='';
                        
                        if(response.Items[0].Line1 != '') {
                            addressline = addressline + response.Items[0].Line1;
                        }
                        if(response.Items[0].Line2 != '') {
                            addressline = addressline + response.Items[0].Line2;
                        }
                        if(response.Items[0].Line3 != '') {
                            addressline = addressline + response.Items[0].Line3;
                        }
                        
                        // var res = response.Items[0];
                        // var addressvalue = res.Label;
                        // var arr ;
                        // arr = addressvalue.split("\n");
                        
                        // var fullAddress;
                        this.showSelectedAddresses = true;

                        // if(response.Items[0].Province == '') {
                        //     fullAddress = addressline+'\n'+response.Items[0].City+'\n'+response.Items[0].PostalCode+'\n'+response.Items[0].CountryName;
                        //     this.fullAddressForHtml = addressline+'<br/>'+response.Items[0].City+'<br/>'+response.Items[0].PostalCode+'<br/>'+response.Items[0].CountryName;
                            
                        // } else {
                        //     fullAddress = addressline+'\n'+response.Items[0].City+'\n'+response.Items[0].Province+'\n'+response.Items[0].PostalCode+'\n'+response.Items[0].CountryName; 
                        //     this.fullAddressForHtml = addressline+'<br/>'+response.Items[0].City+'<br/>'+response.Items[0].Province+'<br/>'+response.Items[0].PostalCode+'<br/>'+response.Items[0].CountryName;
                        // }

                        // const resBox = this.template.querySelector(".niManual");
                        // resBox.innerText = fullAddress;	
                        // resBox.innerHTML = this.fullAddressForHtml;
                        // document.getElementsByClassName("niManual").disply= none;

                        //console.log('Line 400 api call success -> ',resBox.innerHTML);

                        console.log('BuildingNumber-->>'+response.Items[0].BuildingNumber); 
                        console.log('BuildingName-->>'+response.Items[0].BuildingName); 
                        console.log('SubBuilding-->>'+response.Items[0].SubBuilding); 
                        console.log('Test record-->>'+response.Items[0].AdminAreaName);
                        
                        this.streetName=addressline;
                        this.townCity=response.Items[0].City;                        
                        this.county=response.Items[0].Province;
                        this.postCode=response.Items[0].PostalCode;
                        this.country=response.Items[0].CountryName;

                        var returnAddress = {};
                        returnAddress.AddressLine = addressline;
                        returnAddress.Street = response.Items[0].Line3;
                        returnAddress.Town = response.Items[0].City;
                        returnAddress.County = response.Items[0].Province;
                        returnAddress.Postcode = response.Items[0].PostalCode;
                        returnAddress.Country = response.Items[0].CountryName;
                        returnAddress.localAuthorityArea = response.Items[0].AdminAreaName;
                        if(response.Items[0].BuildingNumber == '') {
                            // this.isHouse = true;
                            returnAddress.houseNo = response.Items[0].BuildingName;

                        } else {
                            // this.isHouse = true;
                            returnAddress.houseNo = response.Items[0].BuildingNumber;
                        }

                        console.log('Line 434 -> from child ->  ',JSON.stringify(returnAddress));

                        // Calling parent using Event with data START
                        const myEvent = new CustomEvent('selectingaddress', {
                            detail: {
                                addressType: this.addresslabel,
                                addressObj: returnAddress
                            }
                        });
                        this.dispatchEvent(myEvent);
                        // Calling parent using Event with data END

                        console.log('Line 445 -> from child ');
                        
                        //  console.log(response.Items[0].Line3+' --<addressline-->>'+addressline); 
                        //  console.log('BuildingNumber-->>'+response.Items[0].BuildingNumber); 
                        //  console.log('BuildingName-->>'+response.Items[0].BuildingName); 
                        //  console.log('SubBuilding-->>'+response.Items[0].SubBuilding); 
                        //  console.log('Test record-->>'+response.Items[0].AdminAreaName);
                        /* if(arr.length > 5) {
                            var addressline = arr[arr.length-6] + ' \n ' +arr[arr.length-5];
                            component.set('v.AddressLine1',addressline);
                            
                        } else {
                             component.set('v.AddressLine1',arr[arr.length-5]);
                        } */
                        // alert( component.get('v.PostCode'));

                        // To include in the code
                        //var vx = component.get("v.method");
                        //$A.enqueueAction(vx);   
                        
                        /*document.getElementById("output").style.display = "block";
                        document.getElementById("seperator").style.display = "block";
                        document.getElementById("manualAddress").style.display = "none";*/
                        
                        this.showAddresses = false;
                    }
                }
            }
        }
        http.send(params); 
    }
    
}