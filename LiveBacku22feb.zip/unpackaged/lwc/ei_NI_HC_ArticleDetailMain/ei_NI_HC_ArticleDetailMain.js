import { LightningElement, api, track,wire } from 'lwc';
import { getRecord,getFieldValue } from 'lightning/uiRecordApi';
import publicUrlForKnowledge from '@salesforce/apex/EI_NI_knowledgeArticleDetail.publicUrlForKnowledge';
import { NavigationMixin } from 'lightning/navigation';
import NI_TDS_Website_assets from '@salesforce/resourceUrl/NI_TDS_Website_assets';


const fields = [
    // Add the fields you want to display
    'Knowledge__kav.Knowledge_Article_Category__r.Name',
    'Knowledge__kav.Title',
    'Knowledge__kav.Description__c',
    'Knowledge__kav.Knowledge_Article_Category__c',
    
    // Add more fields as needed
];


export default class Ei_NI_HC_ArticleDetailMain extends NavigationMixin(LightningElement) {
    docIcon=NI_TDS_Website_assets+'/assets/img/docicon.svg';
    //Filer banner and resource type Attribute
    @api firstLink;
    @api secondLink;
    @api thirdLink;
    @api fourthLink;
    @api tenantLabel;
    @api landlordLabel;
    @api agentLabel;
    @api custodialLabel;
    @api insuredLabel;
    @api filterBannerHeading;
    @api selectProductLabel;
    @api resourceNavigationHeading;
    @api fifthLink;
    @api fifthActiveLink;
    @api resourceNav1stLabel;
    @api resourceNav2ndLabel;
    @api resourceNav3rdLabel;
    @api resourceNav4thLabel;
    @api resourceNav5thLabel;
    @api custodialSummary;
    @api insuredSummary;
    @api norelevantresultmsg;
    @api articletypebacklink;
    @api recordId;

    @track record;
    @track wiredRecord;
    @track title;
    @track description;
    @track Articletype;
    @track Articlebacklink;
    @track ArticlebacklinkID;    
    @track publicdocUrlLink;
    @track filterSelection = {customerType: 'Tenant', productType: 'Custodial',recordType:'FAQ'};
    @track isArticleTypeNews = false;
   
    get isarticletypeFAQ() {
        if(this.Articletype==='FAQ') {
            return true;
        }
        else {
            return false;
        }
    }

    get isarticletypecaseStudy() {
        if(this.Articletype==='Case Study') {
            return true;
        }
        else {
            return false;
        }
    }

    get isarticletypeGuide() {
        if(this.Articletype==='Guide') {
            return true;
        }
        else {
            return false;
        }
    }

    get isarticletypeTemplate() {
        if(this.Articletype==='Template') {
            return true;
        }
        else {
            return false;
        }
    }

    @wire(getRecord, { recordId: '$recordId', fields: fields })
    loadKnowledge({error, data}) {
        console.log('Title=' +data.fields.Title.value);
        console.log('Description=' +data.fields.Description__c.name);
        console.log( 'Article type name=' +data.recordTypeInfo.name);
        console.log('Article Type Id=' +data.recordTypeInfo.recordTypeId);
        console.log('Article Category TypeID=' +data.fields.Knowledge_Article_Category__c.value);
        console.log('Article category TypeName=' +data.fields.Knowledge_Article_Category__r.displayValue);

        // Knowledge_Article_Categories__c detail

        console.log('line no93',data);

        // for print data on html
        if(data)
            console.log('Apex Class Test='+JSON.stringify(data));
            this.title=data.fields.Title.value;
            this.description=data.fields.Description__c.value;
            this.Articletype=data.recordTypeInfo.name;
            this.Articlebacklink=data.fields.Knowledge_Article_Category__r.displayValue;
            this.LinkUrlName=data.fields.Knowledge_Article_Category__c.value;
            this.articletypebacklink = this.articletypebacklink + this.LinkUrlName;
            if(this.Articletype=='News') {
                this.isArticleTypeNews = true;
            }
            console.log(`Line 118 Articletype -> ${this.Articletype} isArticleTypeNews -> ${this.isArticleTypeNews}`)
          
            //  For Apex Class for document download
            console.log('line no >103' +data.id);
            publicUrlForKnowledge({ knowledgeId: data.id })
            .then(result => {
                this.publicdocUrlLink = result;                
                console.log('Apex Class Result='+result);
            })
            .catch(error => {
                console.error('Error retrieving public url : ', error);
            });   
            this.template.querySelector('c-child-helpcentre-resource-type-nav-v2').dynamicLoad(this.Articletype);
    }

    connectedCallback() {    
        console.log('for nav2'+this.Articletype);    
    }

    handleChange() {
        console.log('line 140 in ei_NI_HC_ArticleDetailMain');
        this.redirectPageToResourcePage();
    }

    handleArticleTypeChangeEvent(event) {
        //this.Articletype=event.detail.recordTypeProp;
    }

    redirectPageToResourcePage(){  
        var redirectURL;
        console.log('line 150 in ei_NI_HC_ArticleDetailMain');
        if(this.Articletype==='FAQ'){        
            redirectURL= this.firstLink;
        }
        if(this.Articletype==='Case Study'){        
            redirectURL= this.secondLink;
        } 
        if(this.Articletype==='Guide'){        
            redirectURL= this.thirdLink;
        } 
        if(this.Articletype==='Template'){        
            redirectURL= this.fourthLink;
        }          
        
        const pageReference = {
            type: 'standard__webPage',
            attributes: {
                url: redirectURL // Specify the path to the target page
            }
        };
        // Use the NavigationMixin to navigate to the target page
        this[NavigationMixin.Navigate](pageReference);
    }

}