import { LightningElement,api } from 'lwc';
import { loadScript } from 'lightning/platformResourceLoader';
import NI_TDS_Website_assets from '@salesforce/resourceUrl/NI_TDS_Website_assets';


export default class LWCGoogleTranslate extends LightningElement {    

    connectedCallback(){
        console.log('ILWCGoogleTranslate loading');        
        //loadScript(this, NI_TDS_Website_assets+'/assets/scripts/google-translate-element.js').then(() => {                        
        loadScript(this, 'https://translate.google.com/translate_a/element.js').then(() => {                        
            console.log('translate.google.com/translate_a/element.js loaded');                                            
            loadScript(this, NI_TDS_Website_assets+'/assets/scripts/google-function-local.js').then(() => {            
                console.log('google-function-local starting');  
                // setTimeout(this.callGoogleTranslate(), 5000); 
                setTimeout(() => {
                    try {
                        this.callGoogleTranslate();
                    } catch (error) {
                        console.log('Line 20 google-function-local error -> '+JSON.stringify(error));
                    }
                }, 3000)
                
                console.log('google-function-local executed');            
              }); 
          });
        console.log('LWCGoogleTranslate loaded');
    }

    callGoogleTranslate() {
        googleTranslateElementInit();
    }

}