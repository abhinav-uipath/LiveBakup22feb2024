import { LightningElement, wire, track, api } from 'lwc';
import EWITheme from '@salesforce/resourceUrl/EWITheme';
import getSecureURI from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.getSecureURI';
import saveFile from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.saveFile';
import deleteFileAzure from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.deleteFileAzure';
import getHelpArticleDocument from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.getHelpArticleDocument';

export default class EI_EWI_fileUpload extends LightningElement {
    feather_upload =  EWITheme + '/assets/img/feather-download.svg';
    RIght_Check = EWITheme + '/assets/img/RIght_Check.png';
    Trash = EWITheme + '/assets/img/Trash.png';
    View_icon = EWITheme + '/assets/img/View_icon.svg';
    warning_icon = EWITheme + '/assets/img/warning_icon.png';
    question_circle = EWITheme + '/assets/img/question-circle.png';

    @track fileData;
    @track fileList = [];
    @track flType= '';
    @track fileName = 'No file Selected';
    @track fileSize = '';
    @track fileLable = '';
    @track fileLableMSG = '';
    @track isUpload = false;
    @track totalFileSize = 0;
    @track uploadingFileSize = 0;
    @track fileNameInAzure = '';
    @track showFileUpload = true;
    @track showFileList = false;
    @track totalNoOfEvidance = 0;
    @track fileLabelVisible = false;
    @track filesAllowed = 0;
    @track show_5_FileError_AGLL = false;
    @track show_5_FileError_TT = false;
    @track isUploadDisabled = false;
    @track isFileSizeError = false;
    @track isFileSizeErrorcheckin = false;
@track evidanceAttachment22=[]

    @api isDisable;
    @api recordId;
    @api disputeId;
    @api evidanceAttachment = [];
    @api evidenceCategories;
    @api userType;
    @api source;
    @api scheme;
    @api checkin;
    @api checkout;

    // secureURI = 'https://ewinsureddev.blob.core.windows.net/evidence?sp=rw&st=2021-06-18T15:27:12Z&se=2031-06-18T23:27:12Z&spr=https&sv=2020-02-10&sr=c&sig=ny8xLiSPlms%2FpN%2FtAIYuJaJI7VNQBqc9eqL7V%2BlrQLs%3D';

    get isNonEvidenceFile(){
        if(this.totalNoOfEvidance < 1){
            return true;
        }else{
            return false;
        }
    }

    @wire(getSecureURI, {scheme:'EWI'})
    wiremethod({error, data}){
        if(data){
            this.secureURI = data;
            console.log('this.secureURI => ' + this.secureURI);
        }else if(error){
            console.log('getSecureURI error => ' + JSON.stringify(error));
        }
    }

    connectedCallback(){
        // console.log('evidanceAttachment.length => ' + this.evidanceAttachment.length);
        // console.log('this.totalNoOfEvidance => ' + this.totalNoOfEvidance);
        this.evidanceAttachment22 = this.evidanceAttachment;
        let fiteredEviAttachments = [];
        let counttotalNoOfEvidance = 0;
        if(this.evidanceAttachment22)
        {
            for(let i =0;i<this.evidanceAttachment22.length; i++)
            {
                if(this.evidenceCategories ==this.evidanceAttachment22[i].Evidence_Categories__c && this.userType == this.evidanceAttachment22[i].User_Type__c) 
                {
                    counttotalNoOfEvidance++;
                    this.showFileList = true;
                    fiteredEviAttachments.push(this.evidanceAttachment22[i]);
                }
            }
            this.evidanceAttachment22 = fiteredEviAttachments;
            this.totalNoOfEvidance = counttotalNoOfEvidance;
            console.log("evidenceCategories => " + this.evidenceCategories);
            console.log("userType => " + this.userType);
            console.log("checkin => " + this.checkin);
            console.log("checkout => " + this.checkout);
            console.log("evidanceAttachment22 => " + this.evidanceAttachment22);
            console.log("totalNoOfEvidance => " + this.totalNoOfEvidance);

            if(this.evidenceCategories =='Tenant obligations' || this.evidenceCategories =='Inventorycheck in report'||
                this.evidenceCategories =='Check out report'|| this.evidenceCategories =='Rent statement')
            {
                if(this.totalNoOfEvidance > 0){
                    this.showFileUpload = false;
                }
            }
            else if(this.totalNoOfEvidance >= 10 && this.evidenceCategories=='Cleaning' && this.userType == 'Tenant') {
                this.showFileUpload = false;
                this.filesAllowed = 10;
                this.show_5_FileError_TT = true; 
            }
            else if(this.totalNoOfEvidance >= 5 && this.evidenceCategories!='Cleaning' && this.userType == 'Tenant') {
                this.showFileUpload = false;
                this.filesAllowed = 5;
                this.show_5_FileError_TT = true;            
            }
            else if(this.totalNoOfEvidance >= 10 && this.evidenceCategories=='Cleaning' && (this.userType=='Agent' || this.userType=='Independent-Landlord' || this.userType=='Non-Member Landlord' || this.userType=='Landlord')) {
                this.showFileUpload = false;
                this.filesAllowed = 10;
                this.show_5_FileError_AGLL = true; 
            }
            else if(this.totalNoOfEvidance >= 5 && this.evidenceCategories!='Cleaning' && (this.userType=='Agent' || this.userType=='Independent-Landlord' || this.userType=='Non-Member Landlord' || this.userType=='Landlord')) {
                this.showFileUpload = false;
                this.filesAllowed = 5;
                this.show_5_FileError_AGLL = true;            
            }
        }
    }

    // renderedCallback(){
    //     console.log('renderedcallback');
    //     console.log('evidanceAttachment22.length => ' + this.evidanceAttachment22.length);
    //     console.log('this.totalNoOfEvidance => ' + this.totalNoOfEvidance);
    //     let fiteredEviAttachments = [];
    //     let counttotalNoOfEvidance = 0;
    //     if(this.evidanceAttachment22)
    //     {
    //         for(let i =0;i<this.evidanceAttachment22.length; i++)
    //         {
    //             if(this.evidenceCategories ==this.evidanceAttachment22[i].Evidence_Categories__c && this.userType == this.evidanceAttachment22[i].User_Type__c) 
    //             {
    //                 counttotalNoOfEvidance++;
    //                 this.showFileList = true;
    //                 fiteredEviAttachments.push(this.evidanceAttachment22[i]);
    //             }
    //         }
    //         this.evidanceAttachment22 = fiteredEviAttachments;
    //         this.totalNoOfEvidance = counttotalNoOfEvidance;
    //         if(this.evidenceCategories =='Tenant obligations' || this.evidenceCategories =='Inventorycheck in report'||
    //             this.evidenceCategories =='Check out report'|| this.evidenceCategories =='Rent statement')
    //         {
    //             if(this.totalNoOfEvidance > 0){
    //                 this.showFileUpload = false;
    //             }
    //         }
    //         else if(this.totalNoOfEvidance >= 5) {
    //             this.showFileUpload = false;
    //         }
    //     }
    // }

    openfileUpload(event) {
        
        this.fileList = event.target.files;
        const file = event.target.files[0];
        console.log('file => ' + JSON.stringify(file));
        console.log('file.name => ' + file.name);
        var icon = file.name.toLowerCase();
        console.log('icon => ' + icon);

        const ext2 = ['.csv','.msg', '.doc', '.docx', '.pdf', '.ppsx', '.ppt', '.pptx', '.rtf', 
                    '.txt', '.xls', '.xlsx', '.odt', '.bmp', '.jpg', '.jpeg', '.png', '.tif', '.tiff', '.mp3', '.wav', 
                    '.mov', '.mpeg', '.mpg', '.zip'];
                    
        var fileTypeCheck = ext2.some(el => icon.endsWith(el));
        console.log('fileTypeCheck => ' + fileTypeCheck);
        if(fileTypeCheck==false){
            return alert("File type not supported!");
        }
        else{
            this.flType = '.'+file.name.split('.')[1];
            console.log('file.flType => ' + this.flType);
            this.fileName = file.name;
            console.log('this.fileName => ' + this.fileName);
            this.fileSize = file.size;
            console.log('this.fileSize => ' + this.fileSize);
            let fileSizeinMB = this.fileSize/1000000; // 1MB = 1000000 bytes
            console.log('fileSizeinMB => ' + fileSizeinMB);
            console.log('checkin => ' + this.checkin);
            console.log('checkout => ' + this.checkout);
            var filecheckIn = this.checkin;
            var filecheckOut = this.checkout;
            if(filecheckIn == true  || filecheckOut == true){
                if(fileSizeinMB > 100){
                    this.isFileSizeErrorcheckin = true;
                }else{
                    this.isFileSizeError = false;
                    this.totalFileSize = parseInt(Math.ceil(file.size / 1024) );  //1 byte = 0.0009765625 Kilobytes
                    console.log('this.totalFileSize => ' + this.totalFileSize);

                    // let icon = file.name.toLowerCase();
                    // console.log('icon => ' + icon);

                    const ext1 = ['.png','.msg', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp'];
                    //const ext = ['.pngooo099'];
                    var fileTypeCheckisImage = ext1.some(el => icon.endsWith(el));
                    console.log("fileTypeCheckisImage => " + fileTypeCheckisImage);
                    if(fileTypeCheckisImage==true){
                    console.log("if true");
                        
                        this.fileLabelVisible = true;
                        this.template.querySelector('filelabel').classList.add('divShow');
                        this.template.querySelector('filelabel').classList.remove('divHide');
                    }
                    else{
                        this.fileLabelVisible = false;
                        this.fileLable = '';
                        console.log("this.fileLabelVisible => " + this.fileLabelVisible);
                        this.readFile(file);
                        // console.log('icon => ' + icon);
                        // const ext2 = ['.csv', '.doc', '.docx', '.pdf', '.ppsx', '.ppt', '.pptx', '.rtf', 
                        // '.txt', '.xls', '.xlsx', '.odt', '.bmp', '.jpg', '.jpeg', '.png', '.tif', '.tiff', '.mp3', '.wav', 
                        // '.mov', '.mpeg', '.mpg', '.zip'];
                        // //const ext = ['.pngooo099'];
                        // var fileTypeCheck = ext2.some(el => icon.endsWith(el));
                        // console.log('fileTypeCheck => ' + fileTypeCheck);
                        // if(fileTypeCheck==true){
                        //     this.readFile(file);
                        // }
                    }
                }
             }
             else
             {
                if(fileSizeinMB < 20){
                    this.isFileSizeError = false;
                    this.totalFileSize = parseInt(Math.ceil(file.size / 1024) );  //1 byte = 0.0009765625 Kilobytes
                    console.log('this.totalFileSize => ' + this.totalFileSize);

                    // let icon = file.name.toLowerCase();
                    // console.log('icon => ' + icon);

                    const ext1 = ['.png','.msg', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp'];
                    //const ext = ['.pngooo099'];
                    var fileTypeCheckisImage = ext1.some(el => icon.endsWith(el));
                    console.log("fileTypeCheckisImage => " + fileTypeCheckisImage);
                    if(fileTypeCheckisImage==true){
                    console.log("if true");
                        
                        this.fileLabelVisible = true;
                        this.template.querySelector('filelabel').classList.add('divShow');
                        this.template.querySelector('filelabel').classList.remove('divHide');
                    }
                    else{
                        this.fileLabelVisible = false;
                        this.fileLable = '';
                        console.log("this.fileLabelVisible => " + this.fileLabelVisible);
                        this.readFile(file);
                        // console.log('icon => ' + icon);
                        // const ext2 = ['.csv', '.doc', '.docx', '.pdf', '.ppsx', '.ppt', '.pptx', '.rtf', 
                        // '.txt', '.xls', '.xlsx', '.odt', '.bmp', '.jpg', '.jpeg', '.png', '.tif', '.tiff', '.mp3', '.wav', 
                        // '.mov', '.mpeg', '.mpg', '.zip'];
                        // //const ext = ['.pngooo099'];
                        // var fileTypeCheck = ext2.some(el => icon.endsWith(el));
                        // console.log('fileTypeCheck => ' + fileTypeCheck);
                        // if(fileTypeCheck==true){
                        //     this.readFile(file);
                        // }
                    }
                }else{
                    this.isFileSizeError = true;
                }
            }
        }
    }

    handleChangeFileLable(event){
        this.fileLable = event.target.value;
        console.log('fileLabel => ' + this.fileLable);
    }

    addEvidence(){
        //var files = event.getSource().get("v.files");
        // alert('addEvidence');
        this.isUploadDisabled = true;
        const file = this.fileList[0];
        // alert('file.name => ' + file.name);
        var getFileLabel = this.fileLable;
        if(getFileLabel=='' && this.fileLabelVisible == true){
            // alert('first if');
            // component.set("v.fileLable", 'Please provide a label to upload image.');
            this.fileLableMSG = 'Please provide a label to upload an image.';
            this.isUploadDisabled = false;
        }else if(getFileLabel.length > 50){
            // alert('second if');
            this.fileLableMSG = 'Character limit is 50.';
            this.isUploadDisabled = false;
        }else{
            // alert('else');
            // this.fileLable = '';
            this.fileLableMSG = '';
            this.readFile(file);
        }
        console.log('File Label => ' + this.fileLabel);
    }

    readFile(file){
        this.isUpload = true;
        this.template.querySelector('.uploadbar').style.width = '25%';
        this.uploadingFileSize = parseInt(this.totalFileSize/4);
        const currentDate = new Date();
        const timestamp = currentDate.getTime();
        var baseUrl = this.secureURI;
        var baseUrlLength = baseUrl.length;
        var indexOfQueryStart = baseUrl.indexOf("?");
        var sasKeys = baseUrl.substring(indexOfQueryStart, baseUrlLength);
        var submitUri = baseUrl.substring(0, indexOfQueryStart) + '/'+ timestamp +'-'+ file.name + sasKeys;
        this.fileNameInAzure = timestamp +'-'+ file.name;
        console.log('submitUri => ' + submitUri);
        var reader = new FileReader()
        reader.onload = () => {
            var base64 = reader.result.split(',')[1];
            console.log('filetype => ' + file.name.split('.')[1]);
            
            this.fileData = {
                'filetype': '.'+file.name.split('.')[1],
                'filename': file.name,
                'base64': base64,
            }
            
            this.template.querySelector('.uploadbar').style.width = '55%';
            this.uploadingFileSize = parseInt(this.totalFileSize/2);
            // for(var i=0; i<this.totalFileSize+1; i++){
            //     this.uploadingFileSize = i;
            // }
            this.uploadToAzure(file, submitUri); // used for upload file on Azure
        }
        reader.readAsDataURL(file);
    }

    uploadToAzure(file, submitUri) {
        // isSubmitEdiEvidenceAllowed({caseId: this.recordId}).then(result => {

        // }).catch(error => {
        //     console.log('getclaimdetailsforevidence error => ' + JSON.stringify(error), error);
        // });
        //debugger;
        let date = JSON.stringify(new Date(file.lastModified));
        let datesplit = date.replace("T",' ');
        let finaldate = datesplit.slice(1, 20);
        this.template.querySelector('.uploadbar').style.width = '65%';
        this.uploadingFileSize = parseInt(this.totalFileSize/1.6);
        console.log('uploadToAzure file => ' + file);
        console.log('uploadToAzure submitUri => ' + submitUri);
        var xhr = new XMLHttpRequest();
        var endPoint = submitUri;
        
        xhr.open("PUT", endPoint, true);
        xhr.setRequestHeader('x-ms-blob-type', 'BlockBlob');
        console.log('uploadToAzure file => ' + file.type);
        xhr.setRequestHeader('Content-Type', file.type);
        xhr.onreadystatechange = () => {
            console.log("xhr.readyState => " + xhr.readyState);
            console.log("xhr.status => " + xhr.status);
            if (xhr.readyState === 4 && xhr.status === 201) {   
                
                this.template.querySelector('.uploadbar').style.width = '75%';
                this.uploadingFileSize = parseInt(this.totalFileSize/1.3);
                console.log('before call saveFile');

                saveFile({
                    parentId: this.recordId,
                    disputeId :this.disputeId,
                    //disputeId: null,
                    fileName: file.name,
                    azureLink: submitUri,
                    userType: this.userType,
                    fileType :(file.name).split('.').pop(),
                    fileSize :this.totalFileSize, //file.size,
                    fileLable : this.fileLable,
                    evidenceCategories : this.evidenceCategories,
                    fileNameInAzure : this.fileNameInAzure,
                    source : this.source,
                    scheme : this.scheme,
                    createdate : finaldate
                }).then(result=>{
                    if(result == null){
                        const nEvent = new CustomEvent('editevidenceattachmentlist', {
                            detail: {
                                type: 'Case Status Changed',
                                evidanceAttachment : null
                            }
                        });
                        this.dispatchEvent(nEvent);
                    }else{
                        this.template.querySelector('.uploadbar').style.width = '95%';
                        this.uploadingFileSize = parseInt(this.totalFileSize/1.1);
                        let ReturnValue = result;
                        console.log('saveFile result => ' + JSON.stringify(result));
                            
                        let evidanceAttachment22=[];
                        if(this.evidanceAttachment22)
                        {
                            evidanceAttachment22 = this.evidanceAttachment22;
                        }
                        evidanceAttachment22.push(ReturnValue);
                        this.evidanceAttachment22 = evidanceAttachment22;

                        this.showFileList = true;
                        this.totalNoOfEvidance++;
                        if(this.evidenceCategories =='Tenant obligations' || this.evidenceCategories =='Inventorycheck in report'||
                            this.evidenceCategories =='Check out report'|| this.evidenceCategories =='Rent statement')
                        {
                            if(this.totalNoOfEvidance > 0){
                                this.showFileUpload = false;
                            }
                        }
                        else if(this.totalNoOfEvidance >= 10 && this.evidenceCategories =='Cleaning' && this.userType == 'Tenant') {
                            this.showFileUpload = false;
                            this.filesAllowed = 10;
                            this.show_5_FileError_TT = true;            
                        }
                        else if(this.totalNoOfEvidance >= 5 && this.evidenceCategories!='Cleaning' && this.userType == 'Tenant') {
                            this.showFileUpload = false;
                            this.filesAllowed = 5;
                            this.show_5_FileError_TT = true;            
                        }
                        else if(this.totalNoOfEvidance >= 10 && this.evidenceCategories =='Cleaning' && (this.userType=='Agent' || this.userType=='Independent-Landlord' || this.userType=='Non-Member Landlord' || this.userType=='Landlord')) {
                            this.showFileUpload = false;
                            this.filesAllowed = 10;
                            this.show_5_FileError_AGLL = true;            
                        }
                        else if(this.totalNoOfEvidance >= 5 && this.evidenceCategories!='Cleaning' && (this.userType=='Agent' || this.userType=='Independent-Landlord' || this.userType=='Non-Member Landlord' || this.userType=='Landlord')) {
                            this.showFileUpload = false;
                            this.filesAllowed = 5;
                            this.show_5_FileError_AGLL = true;            
                        }
                        
                        const nEvent = new CustomEvent('editevidenceattachmentlist', {
                            detail: {
                                type: 'upload',
                                evidanceAttachment : ReturnValue
                            }
                        });
                        this.dispatchEvent(nEvent);

                        this.template.querySelector('.uploadbar').style.width = '0%';
                        this.fileData = null;
                        this.flType = '';
                        this.fileName = '';
                        this.fileSize = '';
                        this.fileLable = '';
                        this.azureLink = '';
                        this.fileSFId = '';
                        this.fileNameInAzure = '';
                        this.isUpload = false;
                        this.uploadingFileSize = 0;
                        this.totalFileSize = 0;
                        this.fileLabelVisible = false;
                        this.isUploadDisabled = false;
                        // Console log the user with the value returned from the server
                        // const toastEvent = new ShowToastEvent({
                        //     title: 'Info',
                        //     message: 'File Uploaded Successfully'+submitUri,
                        //     type: 'success'
                        // });
                        // this.dispatchEvent(toastEvent);
                    }
                        
                    }).catch(error => {
                        console.log('getclaimdetailsforevidence error => ' + JSON.stringify(error), error);
                    });
            }
            else{
                //image error code
            }
            
        }
        xhr.send(file);
    }

    deleteFile(event){
        let selectedFileId = event.currentTarget.dataset.myid;
        let fileNameInAzure =event.currentTarget.name;

        //let fileNameInAzure = this.fileNameInAzure;
        let totalNoOfEvidance =this.totalNoOfEvidance;
        let evidenceCategories = this.evidenceCategories;
        
        deleteFileAzure({
            fileNameInAzure: fileNameInAzure,
            RecordId: selectedFileId,
            evidenceCategories :evidenceCategories,
            claimId :this.recordId,
            scheme : this.scheme,
            userType: this.userType
        }).then(result=>{
            console.log("deleteFileAzure result => " + JSON.stringify(result));
            if(result == 'null'){
                const nEvent = new CustomEvent('editevidenceattachmentlist', {
                    detail: {
                        type: 'Case Status Changed',
                        evidanceAttachment : null
                    }
                });
                this.dispatchEvent(nEvent);
            }else{
                // let evidanceAttachment22list = this.evidanceAttachment22;
                let indexfile =-1 ;
                let deletedAttachment = {};
                for(let i=0;i< this.evidanceAttachment22.length;i++)
                {
                    if(this.evidanceAttachment22[i].Id ==selectedFileId)
                    {
                        indexfile=i;
                    }
                }
                console.log("indexfile => " + indexfile);
                console.log("this.evidanceAttachment22 before => " + JSON.stringify(this.evidanceAttachment22));
                deletedAttachment = this.evidanceAttachment22[indexfile];
                console.log("deletedAttachment => " + JSON.stringify(deletedAttachment));
                this.evidanceAttachment22.splice(indexfile,1);
                //this.evidanceAttachment22 = evidanceAttachment22list;
                console.log("this.evidanceAttachment22 after => " + JSON.stringify(this.evidanceAttachment22));

                this.flType = '';
                this.fileName = '';
                this.fileSize = '';
                this.azureLink = '';
                this.fileSFId = '';
                this.fileNameInAzure = '';
                this.upload = false;
                this.success = '';
                this.message = '';
                this.flName = 'No file Selected';
                totalNoOfEvidance--;
                this.totalNoOfEvidance =  totalNoOfEvidance;
                if(evidenceCategories =='Tenant obligations' || evidenceCategories =='Inventorycheck in report'||
                    evidenceCategories =='Check out report'|| evidenceCategories =='Rent statement')
                {
                    this.showFileUpload = true;
                    this.showFileList = false;
                }
                else if(totalNoOfEvidance <= 10 && this.evidenceCategories =='Cleaning' && this.userType == 'Tenant') {
                    this.showFileUpload = true;
                    this.filesAllowed = 10;
                    this.show_5_FileError_TT = false;   
                    if(totalNoOfEvidance ==0)
                    {
                        this.showFileList = false;
                    }
                    else{
                        this.showFileList = true;
                    }
                }
                else if(totalNoOfEvidance <= 5 && this.evidenceCategories!='Cleaning' && this.userType == 'Tenant') {
                    this.showFileUpload = true;
                    this.filesAllowed = 5;
                    this.show_5_FileError_TT = false;   
                    if(totalNoOfEvidance ==0)
                    {
                        this.showFileList = false;
                    }
                    else{
                        this.showFileList = true;
                    }
                }
                else if(totalNoOfEvidance <= 10 && this.evidenceCategories =='Cleaning' && (this.userType=='Agent' || this.userType=='Independent-Landlord' || this.userType=='Non-Member Landlord' || this.userType=='Landlord')) {
                    this.showFileUpload = true;
                    this.filesAllowed = 10;
                    this.show_5_FileError_AGLL = false;      
                    if(totalNoOfEvidance ==0)
                    {
                        this.showFileList = false;
                    }
                    else{
                        this.showFileList = true;
                    }      
                }
                else if(totalNoOfEvidance <= 5 && this.evidenceCategories!='Cleaning' && (this.userType=='Agent' || this.userType=='Independent-Landlord' || this.userType=='Non-Member Landlord' || this.userType=='Landlord')) {
                    this.showFileUpload = true;
                    this.filesAllowed = 5;
                    this.show_5_FileError_AGLL = false;      
                    if(totalNoOfEvidance ==0)
                    {
                        this.showFileList = false;
                    }
                    else{
                        this.showFileList = true;
                    }      
                }

                const nEvent = new CustomEvent('editevidenceattachmentlist', {
                    detail: {
                        type: 'delete',
                        deletedAttachment: deletedAttachment
                    }
                });
                this.dispatchEvent(nEvent);
            }
        }).catch(error=>{
            console.log('delete File error => ' + error + JSON.stringify(error));
        });
        
    }

    getHelpArticleDocument(){
        //alert("call get guide doc");
        window.open('https://ewinsureddev.blob.core.windows.net/ewinsureddev/5003G000008HEUjQAO-1669640484868-TDSHelpArticle%20(1).pdf?sp=rw&st=2022-04-05T08:51:01Z&se=2032-04-05T16:51:01Z&spr=https&sv=2020-08-04&sr=c&sig=vbBtrfu%2BbFNQQp1SY8AZ3kTf2z9MKp%2F3Hnia3FLKKCg%3D', 
                    '_blank');
        // getHelpArticleDocument().then(result=>{
        //    console.log('result => ' + result)
        //    var res = result;
        //    console.log("Guidance document Id => " + res);
        //    window.open("https://thedisputeservice--partcopy--c.documentforce.com/servlet/servlet.FileDownload?file="+res);
        //    // window.open("/servlet/servlet.FileDownload?file="+res); 
        // }).catch(error=>{
        //    consol.log('error => ' + error);
        // });
    }

    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        console.log('hideBootstrapErrors button_Name => '+button_Name);
        if(!this.isDisable){
            switch (button_Name) {
                case "isTenantObligationsEviAttachment":
                this.ClaimsDetails.isTenantObligationsEviAttachment = false;
                break;
                case "isInventorycheckEviAttachmentFound":
                this.ClaimsDetails.isInventorycheckEviAttachmentFound = false;
                break;
                case "isCheckoutReportEviAttachmentFound":
                this.ClaimsDetails.isCheckoutReportEviAttachmentFound = false;
                break;
                case "isRentStatementEviAttachmentFound":
                this.ClaimsDetails.isRentStatementEviAttachmentFound = false;
                break;
                case "show_5_FileError_AGLL":
                this.show_5_FileError_AGLL = false;
                break;
                case "show_5_FileError_TT":
                this.show_5_FileError_TT = false;
                break;
            }
        }
    }
}