import {  LightningElement, track, api  } from 'lwc';

import saveFile from '@salesforce/apex/EI_SDS_uploadBankFileCtrl.importCSVFileLWC';
import isUploadAllowed from '@salesforce/apex/EI_SDS_uploadBankFileCtrl.isUploadAllowed';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

const columns = [
    { label: 'RECORD ID', fieldName: 'Id',type: 'text'  },
    { label: 'FILE NAME', fieldName: 'File_Name__c', type: 'text' },
    { label: 'AMOUNT', fieldName: 'Amount__c', type: 'phone' },
    { label: 'PAYMENT METHOD', fieldName: 'Payment_Method__c', type: 'text' },
    { label: 'COLLECTION DATE', fieldName: 'Collection_Date__c', type: 'date' },
];

export default class EI_SDS_uploadBankFile extends LightningElement {
    @track value = 'BACS';
    filesUploaded = [];
    file;
    fileReader;
    @track totalCount=0;
    @track totalAmount=0;
    @track filetype = 'BACS';
    data = [];
    columns = columns;
    @track showLoadingSpinner = false;
    @track isTrue = false;
    MAX_FILE_SIZE = 1500000;
    fileContents;
    message;
    @track error;
    result1;
    @track isUploadAllowed = false;
    @track fileName = '';
    @api isLoaded = false;
    get options() {
        return [
            { label: 'BACS', value: 'BACS' },
            { label: 'Cheque', value: 'Cheque' }
        ];
    }
    handleChange(event) {
        this.value = event.detail.value;
        this.filetype = event.detail.value;
    }
    handleFilesChange(event) {
        console.log("1===",event.target.files.length);
        if(event.target.files.length > 0) {
            this.filesUploaded = event.target.files;
            console.log("getting executed===",event.target.files.length);
            this.fileName = event.target.files[0].name;
        }
    }
    

   handleSave(){
    console.log("handled save=====");
    this.isLoaded = !this.isLoaded;
    this.isUploadAllowed = false;
     isUploadAllowed({fileName:  this.fileName})
        .then(result => {
            console.log("this.isUploadAllowed11====="+result);
            this.isUploadAllowed = result;
            console.log("this.isUploadAllowed====="+this.isUploadAllowed);
            if(this.isUploadAllowed !== 'undefined' && this.isUploadAllowed === false){
                this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error while uploading File',
                            message: 'File with this name already uploaded',
                            variant: 'error',
                        }),
                        );
                    this.isLoaded = !this.isLoaded;
            }else{
                if(this.filesUploaded.length > 0) {
                    this.uploadHelper();
                }
                else {
                    this.fileName = 'Please select a CSV file to upload!!';
                    this.isLoaded = !this.isLoaded;
                }
            }
        })
        .catch(error => {
            this.error = error;
            console.log('error>'+error);
        });
    }

uploadHelper() {
    console.log("333=====");
    this.file = this.filesUploaded[0];
   if (this.file.size > this.MAX_FILE_SIZE) {
        window.console.log('File Size is to long');
        return ;
    }
    this.showLoadingSpinner = true;
    this.fileReader= new FileReader();
    this.fileReader.onloadend = (() => {
        this.fileContents = this.fileReader.result;
        this.saveToFile();
    });
    this.fileReader.readAsText(this.file);
}
saveToFile() {
    this.data = [];
    console.log("444====="+JSON.stringify(this.fileContents));
    console.log("555====="+this.fileName);
    console.log("666====="+this.filetype);
    saveFile({ base64Data: JSON.stringify(this.fileContents), fileName:  this.fileName,fileType: this.filetype}).then(result => {
        window.console.log('result ====> ');
        window.console.log(result);
        this.data = result;
        this.fileName = this.fileName + ' - Uploaded Successfully';
        this.isTrue = false;
        this.showLoadingSpinner = false;
        this.isUploadAllowed = false;
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success!!',
                message: this.file.name + ' - Uploaded Successfully!!!',
                variant: 'success',
            }),
        );
        this.isLoaded = !this.isLoaded; 
        if(this.filesUploaded.length > 0){
            this.filesUploaded = [];
            this.fileName = '';
            this.totalCount= this.data.length;
            this.totalAmount=this.data.reduce((sum, row) => sum + row.Amount__c, 0);
            this.totalAmount = this.totalAmount.toFixed(2);
        } 
    })
    .catch(error => {
        window.console.log(error);
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error while uploading File',
                message: error.message,
                variant: 'error',
            }),
        );
        this.isLoaded = !this.isLoaded;
    });
}
}