import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import NI_THEME from '@salesforce/resourceUrl/NI_Theme';
import NI_TDS_Website_assets from '@salesforce/resourceUrl/NI_TDS_Website_assets';
import NiSiteLoginLink from '@salesforce/label/c.NI_Site_Login_Link';
import NiLegacyLoginLink from '@salesforce/label/c.NI_Legacy_Login_Link';

import checkUsername from '@salesforce/apex/EI_NI_WebsiteLogin.checkUsername';

export default class Ei_NI_WebsiteLogin extends NavigationMixin(LightningElement) {
    // back_icon = NI_THEME + '/assets/img/arrow_right_white.png';
    imagePath = NI_TDS_Website_assets + '/assets/img/edit.svg';
    label = {
        NiSiteLoginLink, 
        NiLegacyLoginLink
    }

    isLoading = false;
    @track showUser = true;
    @track username = '';
    emailRegex = "[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$";
    @track legacyLoginLink = '';

    @api loginText;
    @api usernameLabelText;
    @api usernamePlaceholderText;
    @api nextButtonText;
    @api passwordLabelText;
    @api passwordPlaceholderText;
    @api registrationInfoText;
    @api agentsButtontext;
    @api landlordsButtontext;
    @api landlordLink;
    @api agentLink;
    @api usernameMandatoryError;
    @api usernamePatternError;

    connectedCallback() {
        Promise.all([
            loadStyle(this, NI_TDS_Website_assets + '/assets/css/custom.css'),
            loadStyle(this, NI_TDS_Website_assets + '/assets/css/custom2.css'),
            loadScript(this, NI_TDS_Website_assets + '/assets/js/plugin.min.js'),
            loadScript(this, NI_TDS_Website_assets + '/assets/js/custom.js')
        ])
            .then(() => {
                console.log('Line 25 Files loaded');  
            })
            .catch(error => {
                console.log('Error => ', JSON.stringify(error));
            });
        
        this.showUser = true;
        // Setting up the form action url
        this.legacyLoginLink = this.label.NiLegacyLoginLink;
        console.log('Line 67 -> '+this.legacyLoginLink);
        console.log('Line 57 -> '+this.username);
        // this.username = sessionStorage.getItem('username', this.username);
        // console.log('Line 57 -> '+this.template.querySelector("[name='enterUsername']").value);
        console.log('Line 57 -> '+this.username);
        this.username = '';
    }

    nextForm() {
        this.showUser = !this.showUser;
    }

    handleUsernameBlur(inputEvent) {
        console.log(`Line 17 event name -> ${inputEvent.target.name} -> event value -> ${inputEvent.target.value}`);
        this.username = inputEvent.target.value.trim();
        // this.template.querySelector("[name='enterUsername']").value = this.username;
        console.log(`Line 18 aftertrim ->${inputEvent.target.value.trim()}->`);
        // this.username.toLowerCase().match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);

    }

    handleNextClick() {
        // this.username = sessionStorage.setItem('username', this.username);
        console.log('Line 19 handleNextClick -> '+this.username);

        let isEmailValid = false;
        const emailRegex=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        // let email = this.template.querySelector("[name='enterUsername']");
        // let emailVal = email.value;
        if(this.username.match(emailRegex)) {
            // email.setCustomValidity("");
            isEmailValid = true;
        }
        else {
            // email.setCustomValidity("Please enter valid email");
            isEmailValid = false;
        }
        // email.reportValidity();
        console.log('Line 73 -> '+isEmailValid);

        if(this.username!='' && this.username!=undefined && this.username!=null && isEmailValid) {
            this.isLoading = true;
            console.log('Line 19 handleUsernameBlur -> '+this.isLoading);
            checkUsername({
                username: this.username
            }).then(result => {
                console.log('Line 40 Result -> '+result);
                if(result.startsWith("Success")) {
                    let resultList = result.split("->");
                    console.log('Line 40 resultList -> '+resultList);
                    if(resultList.length==2) {
                        if(resultList[1]=='User found') {
                            console.log('Line 41 User found');
                            console.log('Line 43 -> '+this.label.NiSiteLoginLink)
                            let niSalesforceLoginLink = this.label.NiSiteLoginLink + '?username=' + this.username;
                            window.open(niSalesforceLoginLink, '_self');   
                        }
                        else if(resultList[1]=='User not found') {
                            console.log('Line 42 User not found');
                            this.showUser = false;
                        }
                    }
                }

                this.isLoading = false;

            }).catch(error => {
                this.isLoading = false;
                console.log('Line 35 Error -> '+JSON.stringify(error));
            })
        }
        
    }

    // submitForm() {
    //     this.callWebhookApi();
    // }

    // callWebhookApi() {
    //     var xhr = new XMLHttpRequest();
    //     // xhr.open('POST', 'https://uat.tdsnorthernireland.com/', true);
    //     xhr.open('POST', 'https://uat.tdsnorthernireland.com/my-options/front-end.thedisputeservicelogin', true);
    //     xhr.withCredentials = true;
    //     xhr.setRequestHeader('Content-Type', 'application/json');
    //     xhr.onload = function() {
    //         var resp = xhr.responseText;
    //         console.log('Line 90 -> '+resp);
    //         console.log('Line 91 -> '+JSON.stringify({ Username: 'client', Password: 'design' }))
    //         if(xhr.status == 200) {
    //             document.querySelector('#status').innerHTML = 'Login successful <a href="http://myapp/app">Go to MyApp</a>';
    //         }
    //         else {
    //             document.querySelector('#status').innerHTML = 'Login Failed : ' + xhr.statusText + '<br /><pre>' + xhr.responseText + '</pre>';
    //         }        
    //     };
    //     xhr.send(JSON.stringify({ Username: 'client', Password: 'design' }));

    //     let niSalesforceLoginLink = 'https://uat.tdsnorthernireland.com/';
    //     window.open(niSalesforceLoginLink, '_blank');   
    // }

    onClickButton() {
        
    }

}