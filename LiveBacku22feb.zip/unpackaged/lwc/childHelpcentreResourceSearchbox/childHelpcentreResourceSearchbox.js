import { LightningElement,track,api } from 'lwc';
import KnowledgeSearchController from '@salesforce/apex/EI_NI_websitehelpcenterapx.KnowledgeSearchController';
export default class ChildHelpcentreResourceSearchbox extends LightningElement {

    _filterSelection;   
    @api
    set filterSelection(value) {
        // Trigger actions in the child component when the parent property changes
        this._filterSelection = value;
        this.connectedCallback();
    }

    get filterSelection() {
        return this._filterSelection;
    }

@track searchText='';
// @api customerType='tenant';
// @api productType='custodial';
@api norelevantresultmsg;
@track resourceList=[];
@track isResourceListEmpty = false;
@track showResult=false;

connectedCallback() {   
    console.log('searchText in connectedcallback: '+this.searchText);
    console.log('customerType connectedcallback'+this.filterSelection.customerType);
    console.log('productType connectedcallback: '+this.filterSelection.productType);
    console.log('Line 55 child component childHelpcentreResourceSearchbox -> '+JSON.stringify(this.filterSelection));
}
// handleEnterClick(event){
    
//     console.log('searchText in handleEnterClick: '+this.searchText);
//     console.log('customerType handleEnterClick'+this.customerType);
//     console.log('productType handleEnterClick: '+this.productType);
//     this.handleSearchClick();
    
// }
handleSearchInputChange(event) {
    this.searchText = event.target.value;
    this.handleSearchClick();
}
        handleSearchClick(){
            var searchTxt = this.template.querySelector('[data-id="searchResourceValue"]').value;
            if (/[^a-zA-Z0-9\s]/.test(searchTxt)) {}
            else{
            this.searchText = searchTxt;
            }
            console.log('searchText in handleSearchClick: '+this.searchText);
            console.log('customerType handleSearchClick'+this.filterSelection.customerType);
            console.log('productType handleSearchClick: '+this.filterSelection.productType);
            console.log('searchText length: '+searchTxt.length);
            if (this.searchText && searchTxt.length > 1) {
                console.log('line 30');
            KnowledgeSearchController({customerType:this.filterSelection.customerType,productType:this.filterSelection.productType, searchValue: this.searchText })
            .then(result => {
                console.log('result: '+JSON.stringify(result));
                console.log('size: '+result.length);
                if(result.length>0) {
                    this.resourceList = result.map(record => ({ Id: record.Id, Title: record.Title, url:'/nitds1/article/'+record.UrlName }));
                    console.log('resourceList: '+this.resourceList);
                    this.isResourceListEmpty = false;
                    this.showResult=true;
                }
                else {
                    this.resourceList = []; 
                    console.log('size is zero');
                    this.isResourceListEmpty = true;
                    this.showResult=true;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                console.error('Error message:', error.message);
                console.error('Stack trace:', error.stack);
            })
            }
            else{
                console.log('line 59');
                this.resourceList = []; 
                this.isResourceListEmpty=false;
                this.showResult=false;
            }
        }
        restrictSpecialCharacters(event) {
            const charCode = (event.which) ? event.which : event.keyCode;
    
            // Allow only alphanumeric characters and spaces
            if ((charCode < 48 || charCode > 57) &&  
                (charCode < 65 || charCode > 90) &&  
                (charCode < 97 || charCode > 122) && 
                charCode !== 32) {                    
                event.preventDefault();
            }
        }
}