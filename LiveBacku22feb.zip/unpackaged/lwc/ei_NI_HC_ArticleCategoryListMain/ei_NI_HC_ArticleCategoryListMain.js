import { LightningElement, api, track } from 'lwc';
import getDynamicButtons from '@salesforce/apex/EI_NI_websitehelpcenterapx.getDynamicButtons';

export default class Ei_NI_HC_ArticleCategoryListMain extends LightningElement {

    // @api tenantLabel;
    @api recordTypeProp;
    @api firstLink;
    @api secondLink;
    @api thirdLink;
    @api fourthLink;
    @api tenantLabel;
    @api landlordLabel;
    @api agentLabel;
    @api custodialLabel;
    @api insuredLabel;
    @api filterBannerHeading;
    @api selectProductLabel;
    @api resourceNavigationHeading;
    @api fifthLink;
    @api fifthActiveLink;
    @api resourceNav1stLabel;
    @api resourceNav2ndLabel;
    @api resourceNav3rdLabel;
    @api resourceNav4thLabel;
    @api resourceNav5thLabel;
    @api custodialSummary;
    @api insuredSummary;
    @api articleCategoryPage;
    @api norelevantresultmsg;
    
    @track filterSelection = {customerType: 'Tenant', productType: 'Custodial',recordType:'FAQ'};
    @track displayedButtons = [];
    @track linkObject = {firstLink:'', secondLink:'', thirdLink:'', fourthLink:'', 
            firstActiveLink:'', secondActiveLink:'', thirdActiveLink:'', fourthActiveLink:''};
    @track firstActiveLink=false;
    @track secondActiveLink=false;
    @track thirdActiveLink=false;
    @track fourthActiveLink=false;
  

    
    

    connectedCallback() {   
        console.log('line 35 in parent connected callback');
        
            console.log('Tenant Label:'+ this.recordTypeProp);
            console.log('faq Label:'+ this.resourceNav1stLabel);
    
        this.filterSelection.recordType=this.recordTypeProp; 
         this.filterSelection.customerType = localStorage.getItem('customerType') || 'Tenant';
         this.filterSelection.productType = localStorage.getItem('productType') || 'Custodial'; 
         console.log('customerType in parent:'+ this.filterSelection.customerType);
         console.log('productType in parent:'+ this.filterSelection.productType);
         
        // this.filterSelection.recordType = localStorage.getItem('filterSelection.recordType') || 'FAQ';  
        
        console.log('Line 45 -> ');
        if(this.recordTypeProp=='FAQ'){
            this.firstActiveLink=true;
        }
        if(this.recordTypeProp=='Casestudy'){
            this.secondActiveLink=true;
        }
        if(this.recordTypeProp=='Guide'){
            this.thirdActiveLink=true;
        }
        if(this.recordTypeProp=='Template'){
            this.fourthActiveLink=true;
        }
         // Setting the linkObject from meta xml attributes
         this.linkObject.firstLink = this.firstLink;
        console.log('Line 42 -> '+this.firstLink);
         this.linkObject.secondLink = this.secondLink;
         this.linkObject.thirdLink = this.thirdLink;
         this.linkObject.fourthLink = this.fourthLink;
         this.linkObject.firstActiveLink = this.firstActiveLink;
         this.linkObject.secondActiveLink = this.secondActiveLink;
         this.linkObject.thirdActiveLink = this.thirdActiveLink;
         this.linkObject.fourthActiveLink = this.fourthActiveLink;
 
         console.log('Line 42 -> '+JSON.stringify(this.linkObject));
         
     }

     renderedCallback() {   
        console.log('Line 44 -> ');
     }
   
    handleChange(event){       
        console.log('handleChange triggered by filters'); 
       // this.filterSelection=event.detail.filterSelection;         
        //this.filterSelection.recordType=this.recordTypeProp;   
        let returnedData = event.detail;
        console.log('line 32 in parent: '+JSON.stringify(returnedData));
        
        console.log('line 32.22 in parent: '+JSON.stringify(returnedData.filterSelection.customerType));
       
        console.log('line 33 in parent: '+JSON.stringify(event.detail.filterSelection));
		this.filterSelection.customerType = returnedData.filterSelection.customerType;
		this.filterSelection.productType = returnedData.filterSelection.productType;

        console.log(this.filterSelection.customerType);
        console.log(this.filterSelection.productType);
        console.log(this.filterSelection.recordType);
        localStorage.setItem('filterSelection.customerType', returnedData.filterSelection.customerType); 
        localStorage.setItem('filterSelection.productType', returnedData.filterSelection.productType); 
        const localStorageValuecustomerType = localStorage.getItem('filterSelection.customerType');
        console.log('Value in local storage customerType: ' + localStorageValuecustomerType);
        const localStorageValueproductType = localStorage.getItem('filterSelection.productType');
        console.log('Value in local storage productType: ' + localStorageValueproductType);
        // Calling the child component to load the dynamic buttons
        this.template.querySelector('c-child-helpcentre-article-category-list').loadDynamicButtons(this.filterSelection);
    }

    handleArticleTypeChangeEvent(event){
        console.log('handleArticleTypeChangeEvent triggered by filters'); 
        let returnedData = event.detail;
		this.filterSelection.recordType = returnedData.filterSelection.recordType;
		console.log('line 49 in parent: '+JSON.stringify(returnedData.filterSelection.recordType));
        console.log(this.filterSelection.customerType);
        console.log(this.filterSelection.productType);
        console.log(this.filterSelection.recordType);
        localStorage.setItem('filterSelection.recordType', returnedData.filterSelection.recordType); 
        const localStorageValue = localStorage.getItem('filterSelection.recordType');
        console.log('Value in local storage: ' + localStorageValue);

        // Calling the child component to load the dynamic buttons
        this.template.querySelector('c-child-helpcentre-article-category-list').loadDynamicButtons(this.filterSelection);
    }

}