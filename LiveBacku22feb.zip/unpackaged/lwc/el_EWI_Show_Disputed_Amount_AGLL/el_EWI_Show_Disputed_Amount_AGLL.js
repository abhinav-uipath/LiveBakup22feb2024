import { LightningElement,track } from 'lwc';
import { NavigationMixin } from "lightning/navigation";
import setDisputedAmount from '@salesforce/apex/EWI_PayDisputedFundsController.setDisputedAmount';
import createCaseFields from '@salesforce/apex/EWI_PayDisputedFundsController.createCaseFields';
import getBulkNumber from '@salesforce/apex/EWI_PayDisputedFundsController.getBulkNumber';
import updateDisputedAmount from '@salesforce/apex/EWI_PayDisputedFundsController.updateDisputedAmount';
import EWITheme from '@salesforce/resourceUrl/EWITheme';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const columnWithoutAddress = [
    { label: 'Disputed Amount', fieldName: 'caseDisputedAmount', type: 'currency' }
];

const columnWithAddress = [
    { label: 'Disputed Amount', fieldName: 'caseDisputedAmount', type: 'currency' },
    { label: 'Tenancy Address', fieldName: 'address', type: 'address'}
];

const columnWithPaymentMethod = [
    { label: 'Disputed Amount', fieldName: 'caseDisputedAmount', type: 'currency' },
    { label: 'Tenancy Address', fieldName: 'address', type: 'address'},
    { label: 'Payment Method', fieldName: 'paymentMethod', type: 'text'}
];

export default class El_EWI_Show_Disputed_Amount_AGLL extends NavigationMixin (LightningElement) {
    ew_arrow_dropleft = EWITheme + '/assets/img/ew-arrow-dropleft.png';
    @track disputedAmount = 0.0;
    @track data = [];
    selectedRows = [];
    columnWithoutAddress = columnWithoutAddress;
    columnWithAddress = columnWithAddress;
    columnWithPaymentMethod = columnWithPaymentMethod;
    PaymentReferenceNumber;
    accountId;
    depositList = [];
    depositId;
    depositStatus;
    depositNumber;
    address;
    isDebitCardSelected = false;
    isBankTransferSelected = false;
    isChequeSelected = false;
    isShowDefaultTable = true;
    showAllButtons = true
    isDebitCardConfirmed = false;
    isBankTransferConfirmed = false;
    isChequeConfirmed = false;
    accessCode1;
    initialPaymentMethod;
    newAmount;
    orignalDiputedAmount;
    @track showDetails=true;

    callSetDisputedAmount(accessCode){
        if(accessCode==null || accessCode == ''){
            this.showDetails=false;
            return;
        }
        setDisputedAmount({accessCode:this.accessCode}).then(result=>{
            if(result==null){
                this.showDetails=false;
                return;
            }
            this.showDetails=true;
            console.log('result of setDisputedAmount : '+JSON.stringify(result));
            if((result.caseDisputedAmount!==undefined) ||(result.caseDisputedAmount!==null)){
                this.disputedAmount = result[0].caseDisputedAmount;
                this.orignalDiputedAmount = result[0].caseDisputedAmount;
                this.data = result;
                this.accountId = result[0].accountId;
                this.depositId = result[0].depositId;
                this.depositStatus = result[0].depositStatus;
                this.depositNumber = result[0].depositNumber;
                this.address = result[0].address;
            }
            console.log('result of data : '+JSON.stringify(this.data));
            console.log('accountId : '+this.accountId);
            console.log('depositId : '+this.depositId);
            console.log('depositStatus : '+this.depositStatus);
        }).catch(error=>{
            console.log('error occured in setDisputedAmount : '+JSON.stringify(error));
        }); 
    }

    connectedCallback(){
        const queryString = window.location.search;
        console.log('queryString => ' + queryString);
        const urlParams = new URLSearchParams(queryString);
        console.log('urlParams => ' + urlParams);
        const caseId = urlParams.get('caseId');
        console.log('caseId => ' + caseId);
        const accessCode = urlParams.get('accessCode');
        this.accessCode = accessCode;
        this.accessCode1 = this.accessCode;
        console.log('accessCode => ' + accessCode);
        const pMethod = urlParams.get('paymentMethod');
        this.initialPaymentMethod = pMethod;

        this.callSetDisputedAmount(this.accessCode);
       

        getBulkNumber().then(result=>{
            console.log('result handleSubmit : '+JSON.stringify(result));
            this.PaymentReferenceNumber = result;
            console.log('PaymentReferenceNumber : '+ this.PaymentReferenceNumber);
        }).catch(error=>{
            console.log('error occured in handleSubmit : '+JSON.stringify(error));
        });
    }
    
    removeZero(event) {
        var edValue = event.target.value;
        function trimNumber(s) {
            while (s.substring(0,1) == '0' && s.length>=1 && !s.includes(".")) { 
                s = s.substring(1,9999); 
            }
            return s;
        }
        var trimeVal = trimNumber(edValue);
        event.target.value = trimeVal;
        
        if(trimeVal.includes('.')){
            var number = trimeVal.split('.');
            console.log('numbs '+number[1]);
            if(number[1].length>2)
            event.target.value = parseFloat(trimeVal).toFixed(2);
        }else{
            event.target.value = trimeVal;
        }
    }
    restrictDecimal(event) {  
        var t = event.target.value;
        return (t.indexOf(".") >= 0) ? (t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)) : t
    }
    handlegotoDepositSummary(){
        if(this.showAllButtons){
        let currentURL = window.location.href;
        console.log('currentURL => ' + currentURL);
        let homeURL = currentURL.split('/s');
        console.log('homeURL => ' + homeURL[0]);
        let redirectToURL = homeURL[0]+'/s/?accessCode='+this.accessCode1;
        console.log('redirectToURL => ' + redirectToURL);
        window.location.href = redirectToURL; // "https://portal.tenancydepositscheme.com/s/?accessCode="+this.accessCode; 
        }else{
            this.showAllButtons = true
            this.isShowDefaultTable = true;
            this.isDebitCardConfirmed = false;
            this.isBankTransferConfirmed = false;
            this.isChequeConfirmed = false;
            this.isDebitCardSelected = false;
            this.isBankTransferSelected = false;
            this.isChequeSelected = false;
            if(this.orignalDiputedAmount !=null || this.orignalDiputedAmount != undefined){
            this.disputedAmount = this.orignalDiputedAmount;
            }
        }
     }

      handleTableSave(event){
        console.log('new deposit value : '+event.target.value);
        let val = this.restrictDecimal(event);
        event.target.value = val;
        
        var valToRound = event.target.value;
        //this.newAmount = valToRound.toFixed(2);
        this.newAmount = valToRound;
        /*if(newAmount <= this.disputedAmount){
        this.disputedAmount = newAmount;
        //this.callSetDisputedAmount(this.accessCode1);
        let temp = [];
        this.data.forEach((res)=>{
            let lineItem = {};
            lineItem.caseDisputedAmount = this.disputedAmount;
            lineItem.address = res.address;
            lineItem.accountId = res.accountId;
            lineItem.depositId = res.depositId;
            lineItem.depositStatus = res.depositStatus;
            lineItem.depositNumber = res.depositNumber;
            lineItem.paymentMethod = res.paymentMethod;
            temp.push(lineItem);
        });
        this.data = temp;
        console.log('data after changing : '+JSON.stringify(this.data));
    }else{
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error',
                message: 'New amount can not be greater than original amount',
                variant: 'error'
            })
        );
    }
        /*updateDisputedAmount({accessCode:this.accessCode1,amount:this.disputedAmount}).then(result=>{
            
        }).catch(error=>{
            console.log('error in updateDisputedAmount : '+JSON.stringify(error));
        });*/
            // Clear all draft values in the datatable
            //this.template.querySelector("lightning-datatable").draftValues = [];
     }

     get isshowTableOrDebitCard(){
        if(this.isShowDefaultTable || this.isDebitCardSelected){
            return true;
        }else{
            return false;
        }
     }

     get isBankOrchequeConfirmed(){
        if(this.isBankTransferConfirmed || this.isChequeConfirmed){
            return true;
        }else{
            return false;
        }
     }

     get isBankOrchequeSelected(){
        if(this.isBankTransferSelected || this.isChequeSelected){
            return true;
        }else{
            return false;
        }
     }

     get isBankOrChequeOrDebitSelected(){
        if(this.isBankTransferSelected || this.isChequeSelected || this.isDebitCardSelected){
            return true;
        }else{
            return false;
        }
     }

     handleSubmitDebitCard(){
        if((this.newAmount == null || this.newAmount == undefined)|| (this.newAmount <= this.disputedAmount)){
            if(!(this.newAmount == null || this.newAmount == undefined || this.newAmount == "")){
            this.disputedAmount = this.newAmount;
            let temp = [];
            this.data.forEach((res)=>{
                let lineItem = {};
                lineItem.caseDisputedAmount = this.disputedAmount;
                lineItem.address = res.address;
                lineItem.accountId = res.accountId;
                lineItem.depositId = res.depositId;
                lineItem.depositStatus = res.depositStatus;
                lineItem.depositNumber = res.depositNumber;
                lineItem.paymentMethod = res.paymentMethod;
                temp.push(lineItem);
            });
            this.data = temp;
            console.log('data after changing : '+JSON.stringify(this.data));
            }
            this.isDebitCardSelected = true;
            this.isBankTransferSelected = false;
            this.isChequeSelected = false;
            this.isShowDefaultTable = false;
            this.showAllButtons = false;
        }else{
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'New amount can not be greater than original amount',
                    variant: 'error'
                })
            );
        }
     }

     handleSubmitBankTransfer(){
        if((this.newAmount == null || this.newAmount == undefined)|| (this.newAmount <= this.disputedAmount)){
            if(!(this.newAmount == null || this.newAmount == undefined || this.newAmount == "")){
            this.disputedAmount = this.newAmount;
            let temp = [];
            this.data.forEach((res)=>{
                let lineItem = {};
                lineItem.caseDisputedAmount = this.disputedAmount;
                lineItem.address = res.address;
                lineItem.accountId = res.accountId;
                lineItem.depositId = res.depositId;
                lineItem.depositStatus = res.depositStatus;
                lineItem.depositNumber = res.depositNumber;
                lineItem.paymentMethod = res.paymentMethod;
                temp.push(lineItem);
            });
            this.data = temp;
            console.log('data after changing : '+JSON.stringify(this.data));
            }
            this.isDebitCardSelected = false;
            this.isBankTransferSelected = true;
            this.isChequeSelected = false;
            this.isShowDefaultTable = false;
            this.showAllButtons = false;
        }else{
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'New amount can not be greater than original amount',
                    variant: 'error'
                })
            );
        }
        
     }

     handleSubmitCheque(){
        
        if((this.newAmount == null || this.newAmount == undefined)|| (this.newAmount <= this.disputedAmount)){
            if(!(this.newAmount == null || this.newAmount == undefined || this.newAmount == "")){
            this.disputedAmount = this.newAmount;
            let temp = [];
            this.data.forEach((res)=>{
                let lineItem = {};
                lineItem.caseDisputedAmount = this.disputedAmount;
                lineItem.address = res.address;
                lineItem.accountId = res.accountId;
                lineItem.depositId = res.depositId;
                lineItem.depositStatus = res.depositStatus;
                lineItem.depositNumber = res.depositNumber;
                lineItem.paymentMethod = res.paymentMethod;
                temp.push(lineItem);
            });
            this.data = temp;
            console.log('data after changing : '+JSON.stringify(this.data));
            }
            this.isDebitCardSelected = false;
            this.isBankTransferSelected = false;
            this.isChequeSelected = true;
            this.isShowDefaultTable = false;
            this.showAllButtons = false;
        }else{
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'New amount can not be greater than original amount',
                    variant: 'error'
                })
            );
        }
     }

     getRowValues(event){
        console.log('row : '+JSON.stringify(event.detail.selectedRows));
        this.selectedRows = event.detail.selectedRows;
     }

     handleNavigateToWorldPay() {
        console.log('handleNavigateToWorldPay called');
        const config = {
            type: 'standard__webPage',
            attributes: {
                //url: 'https://secure-test.worldpay.com/wcc/purchase',
               // method : 'POST'

                url: 'https://secure.worldpay.com/wcc/purchase?instId=1096513&cartId='+this.depositNumber+'&amount='+this.disputedAmount+'&currency=GBP&accId1=THEDISPUTESEM3'+'&MC_accessCode='+this.accessCode1,
                method : 'GET'

                
            },
            state:{
                instId : '1096513',
                cartId : this.PaymentReferenceNumber,
                amount : this.disputedAmount,
                currency : 'GBP',
                accId1 : 'THEDISPUTESEM3'
            }
        };
        this[NavigationMixin.Navigate](config);
      }

     handleSubmit(){
        console.log('submit called');
        const PaymentMethod = null;
        console.log('this.isDebitCardSelected : '+this.isDebitCardSelected);
        console.log('this.isBankTransferSelected : '+this.isBankTransferSelected);
        console.log('this.isChequeSelected : '+this.isChequeSelected);
        if(this.isDebitCardSelected){
            this.handleNavigateToWorldPay();
            this.isDebitCardConfirmed = true;
            this.isDebitCardSelected = false;
            this.PaymentMethod = 'Debit card';
        }else if(this.isBankTransferSelected){
            this.isBankTransferConfirmed = true;
            this.isBankTransferSelected = false;
            this.PaymentMethod = 'Bank transfer';
        }else if(this.isChequeSelected){
            this.isChequeConfirmed = true;
            this.isChequeSelected = false;
            this.PaymentMethod = 'Cheque';
        }
        this.callcreateCaseFields(this.PaymentMethod);
        //this.callUpdateDisputedAmount();
        if(this.initialPaymentMethod==null || this.initialPaymentMethod==undefined)
        {
            this.initialPaymentMethod=this.PaymentMethod;
        }
        let temp = [];
        this.data.forEach((res)=>{
            let lineItem = {};
            lineItem.caseDisputedAmount = this.disputedAmount;
            lineItem.address = res.address;
            lineItem.accountId = res.accountId;
            lineItem.depositId = res.depositId;
            lineItem.depositStatus = res.depositStatus;
            lineItem.depositNumber = res.depositNumber;
            lineItem.paymentMethod = this.PaymentMethod;
            temp.push(lineItem);
        });
        this.data = temp;
        console.log('data after changing pm: '+JSON.stringify(this.data));
     }

     callcreateCaseFields(PaymentMethod){
        createCaseFields({accessCode:this.accessCode1,PaymentMethod:this.PaymentMethod,amount:this.disputedAmount}).then(result=>{

        }).catch(error=>{
            console.log('error in createCaseFields : '+JSON.stringify(error));
        });
     }

     callUpdateDisputedAmount(){
        updateDisputedAmount({accessCode:this.accessCode1,amount:this.disputedAmount}).then(result=>{
            
        }).catch(error=>{
            console.log('error in updateDisputedAmount : '+JSON.stringify(error));
        });
     }
     
}