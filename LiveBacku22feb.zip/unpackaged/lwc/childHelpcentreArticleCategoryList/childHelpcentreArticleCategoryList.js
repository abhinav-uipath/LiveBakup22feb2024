import { LightningElement, api, track } from 'lwc';
import getDynamicButtons from '@salesforce/apex/EI_NI_websitehelpcenterapx.getDynamicButtons';
import NI_website_image_base_url from '@salesforce/label/c.NI_website_image_base_url';

export default class childHelpcentreArticleCategoryList extends LightningElement {    
    // _filterSelection;    
    // @api
    // set filterSelection(value) {
    //     console.log('line 8 in childHelpcentreArticleCategoryList');
    //     // Trigger actions in the child component when the parent property changes
    //     this._filterSelection = value;
    //     this.dynamicButtons=[];
    //     this.connectedCallback();
    //     console.log('childHelpcentreArticleCategoryList');
    // }

    // get filterSelection() {
    //     return this._filterSelection;
    // }

    @track dynamicButtons=[];
    // @track displayedButtons = [];
    @track allButtons = [];
    @track showViewAllButton = false;
    @api filterSelection = {};
    @api articleCategoryPage;
    @track  labelValue = NI_website_image_base_url;
   
    connectedCallback() {         
        console.log('Child component connectedCallback childHelpcentreArticleCategoryList -> ', JSON.stringify(this.filterSelection));
        this.loadDynamicButtons(this.filterSelection);  
           console.log('labelValue: '+this.labelValue);
    }

    @api
    loadDynamicButtons(filterSelection) {    
        this.filterSelection = filterSelection;
        console.log('Line 28 childHelpcentreArticleCategoryList loadDynamicButtons filterSelection -> '+JSON.stringify(this.filterSelection));      
        console.log(this.filterSelection.customerType);      

        getDynamicButtons({ customerType: this.filterSelection.customerType, productType: this.filterSelection.productType, articleType: this.filterSelection.recordType })
            .then(result => {
                //this.dynamicButtons = result;                
                //console.log(this.dynamicButtons);
                console.log('Line 34 result -> '+JSON.stringify(result));
                console.log('Line 34 result.knowledgeArticleList -> '+JSON.stringify(result[0].knowledgeArticleList));
                console.log('size: '+result.length);
                if(result.length>0) {
                    let allButtonsList = result[0].knowledgeArticleList;
                    // this.allButtons = result[0].knowledgeArticleList;
                    this.allButtons = [];
                    for(let button of allButtonsList) {
                        
                        console.log('line 40 button -> '+JSON.stringify(button)); 
                        // button.url = '/NITDSHelpcentre/knowledge-article-categories/'+button.Id;
                        let newButton = {Name: button.Name, Id: button.Id, url:this.articleCategoryPage+button.Id, imageUrl: this.labelValue+button.Image_content_key__c};
                        console.log('line 40 button -> '+JSON.stringify(newButton)); 
                        this.allButtons.push(newButton); 
                    }
                    console.log('line 40 button -> '+JSON.stringify(this.allButtons)); 
                    this.updateDisplayedButtons();
                    console.log('line 40 allButtons -> '+JSON.stringify(this.allButtons)); 
                    this.showViewAllButton = this.allButtons.length > 6;
                    console.log('showViewAllButton-->: '+this.showViewAllButton);
                    let imagelogo=result[0].imageContentKeys
                    console.log('imagelogo: '+imagelogo);
                 }
            })
            .catch(error => {
                console.error('Error retrieving dynamic buttons:', error);
            });
    }

    updateDisplayedButtons() {
        // Show up to 6 buttons by default
        // this.displayedButtons = this.allButtons.slice(0, 6);
        this.dynamicButtons = this.allButtons.slice(0, 6);
    }

    handleViewAll() {
        // Show all buttons
        // this.displayedButtons = this.allButtons;
        this.dynamicButtons = this.allButtons;
        this.showViewAllButton=false;
    }
}