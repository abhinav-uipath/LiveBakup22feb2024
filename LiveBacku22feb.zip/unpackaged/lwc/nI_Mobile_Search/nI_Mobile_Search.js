import { LightningElement ,api,track } from 'lwc';
import NI_TDS_Website_assets from '@salesforce/resourceUrl/NI_TDS_Website_assets';


export default class NI_Mobile_Search extends LightningElement {
    docIcon=NI_TDS_Website_assets+'/assets/img/Iconmobile-search.svg';
     @api result_page_link ='/nitds1/global-search/' 
    @track isSearchVisible = false;
    @track serchcontain;
    
 
    get searchContainerClass() {
        return this.isSearchVisible ? 'toggle-button search-mobile-input' : 'slds-hide';
    }
 
    toggleSearch() {
        this.isSearchVisible = !this.isSearchVisible;
    }
    redirectPage(event){
        // console.log('checkpage redirection',event.target.value);
        if(event.keyCode === 13)
        {
            window.location.href= this.result_page_link+event.target.value; 

        }
        this.serchcontain = event.target.value;

    }
    clickicon(){
        
         window.location.href=this.result_page_link+this.serchcontain; 
        
        // serchcontain = event.target.value;  
    }

}