import { LightningElement, track, wire, api } from 'lwc';
import loqateKey from '@salesforce/label/c.Loqate_key';

export default class Ei_NI_Website_AddressFinder extends LightningElement {

    @api searchAddressStr = '';                 // To store the text entered to find the respective addresses
    @api addresslabel = '';                     // To store the label of the sub address to pass it for the event to parent component
    @api defaultaddress = [];
    @api requiredclass = '';
    @api boldlabel = false;                      // to make address label bold
    @track houseNo = '';                        // To store the house of the address
    @track streetName = ''
    @track townCity = '';                       // To store the town or city of the address
    @track county = '';                         // To store the county of the address
    @track postCode = '';                       // To store the postcode of the address
    @track country = '';
    @track Locality = '';
    @track BuildingName = '';
    @api isHideCountry = false;                      // To store the country of the address
    @track localAuthorityArea = '';
    @track addressResponseList = [];            // To get the response of the addresses data from the api call
    @track childAddressResponseList = [];       // To get the response of the child addresses data from the api call
    @track addressType = '';                    // To get the addresses type either Parent addresses or Child addresses
    @track selectedAddressStr = '';             // To get the current selected address from the dropdown address picklist
    @track fullAddressForHtml = '';
    label = { loqateKey };                    // To store all the custom label in an object          

    @track isManualAddress = false;             // To store if the user wants to enter the address manually
    @track showAddresses = false;               // To store if the user wants to enter the address manually
    @track isHouse = false;
    @track showSelectedAddresses = false;        // To show the current selected address div on the HTML
    @api isDisable = false;                      // To disable input field

    constructor() {
        super();
        // console.log('Child constructor');
    }

    connectedCallback() {
        // console.log('Line 62 -> Child Connected Callback START');
        // console.log('Line 87 -> Child Connected Callback END -> ');
        // console.log('Line 38 -> '+this.defaultaddress.length);
        // console.log('Line 39 -> '+this.showSelectedAddresses);
        console.log('defaultaddress at Address>>>>' + JSON.stringify(this.defaultaddress));
        if (this.defaultaddress.length > 0 /* && !this.defaultaddress[null] */) {
            this.showSelectedAddresses = true;
            this.houseNo = this.defaultaddress[0].houseNo;
            this.streetName = this.defaultaddress[0].Street;
            this.townCity = this.defaultaddress[0].Town;
            this.county = this.defaultaddress[0].County;
            this.postCode = this.defaultaddress[0].Postcode;
            this.country = this.defaultaddress[0].Country;
            //this.BuildingName = this.defaultaddress[0].BuildingName;
            //this.Locality = this.defaultaddress[0].Locality;
        }
    }

    renderedCallback() {
        // console.log('Line 62 -> Child Rendered Callback START');
        // console.log('Line 87 -> Child Rendered Callback END');
    }

    disconnectedCallback() {
        // console.log('Line 62 -> Child Disconnected Callback START');
        // console.log('Line 87 -> Child Disconnected Callback END');
    }

    get returnAddressResponseListSize() {
        return this.addressResponseList.length > 0;
    }

    get isHousePresent() {
        return this.houseNo ? true : false;
    }

    get isStreetPresent() {
        return this.streetName ? true : false;
    }

    get isTownCityPresent() {
        return this.townCity ? true : false;
    }

    get isCountyPresent() {
        return this.county ? true : false;
    }

    get isPostCodePresent() {
        return this.postCode ? true : false;
    }

    get isCountryPresent() {
        return this.country ? true : false;
    }

    enterAddressManually() {
        //this.showSelectedAddresses = false;

        this.isManualAddress = !this.isManualAddress;
        if (!this.isManualAddress) {
            this.showSelectedAddresses = true;
            // setTimeout(function() {
            //     //your code to be executed after 1 second
            //     let resBox = this.template.querySelector(".niManual");
            //     console.log('-->>'+this.fullAddressForHtml);
            //     console.log('-->>'+resBox);
            //     resBox.innerHTML = this.fullAddressForHtml;
            // }, 5000);

        } else {
            this.showSelectedAddresses = false;
        }

    }

    handleLiClick(event) {
        // console.log('Line 92 weird -->>');
    }
    capitalize(s){
        return s.toLowerCase().replace( /\b./g, function(a){ return a.toUpperCase(); } );
    };

    eventManualAddressHandler(event) {
        // console.log('Line 48 -> ',event.target.name);
        // If event takes place due to input of street
        if (event.target.name.includes("Street")) {
            // this.streetName = [this.template.querySelector("lightning-textarea").value];

            this.streetName = this.template.querySelector("lightning-textarea").value;
            this.streetName = this.capitalize(this.streetName);
            // console.log('Line 100 -> ',this.streetName);
            // console.log('Line 100 -> ',typeof this.streetName);
            // Calling parent using Event with data START
            const myEvent = new CustomEvent('fieldchange', {
                detail: {
                    addressType: this.addresslabel,
                    fieldName: event.target.name,
                    value: this.streetName
                }
            });
            this.dispatchEvent(myEvent);
            // Calling parent using Event with data END

        } else {
            if (event.target.name.includes("City")) {
                this.townCity = this.template.querySelector("[name='inputTownCity']").value;
                this.townCity = this.capitalize(this.townCity);

            }  if (event.target.name.includes("County")) {
                this.county = this.template.querySelector("[name='inputCounty']").value;
                this.county = this.capitalize(this.county);

            }  if (event.target.name.includes("Postcode")) {
                this.postCode = this.template.querySelector("[name='inputPostcode']").value.toUpperCase();
                this.template.querySelector('[name="inputPostcode"]').value = this.postCode;
                // this.postCode = this.capitalize(this.postCode);

            }  if (event.target.name.includes("Country")) {
                this.country = this.template.querySelector("[name='inputCountry']").value;
               // this.country = this.capitalize(this.country);

            }  if (event.target.name.includes("House")) {
                this.houseNo = this.template.querySelector("[name='inputHouse']").value;
                this.houseNo = this.capitalize(this.houseNo);

            }  if (event.target.name.includes("BuildingName")) {
                this.BuildingName = this.template.querySelector("[name='SubBuildingName']").value;
                this.BuildingName = this.capitalize(this.BuildingName);

            }  if (event.target.name.includes("Locality")) {
                this.Locality = this.template.querySelector("[name='inputLocality']").value;
                this.Locality = this.capitalize(this.Locality);

            }
            console.log('this.houseNo****', this.houseNo);
            console.log('this.Postcode****', this.postCode);
            console.log('this.County****', this.county);
            console.log('this.City****', this.townCity);
            console.log('this.City****', this.BuildingName);
            console.log('this.City****', this.Locality);

            // Calling parent using Event with data START
           if(event.target.name.includes("Postcode")){
            const myEvent = new CustomEvent('fieldchange', {
                detail: {
                    addressType: this.addresslabel,
                    fieldName: event.target.name,
                    value: this.postCode
                }
            });
            this.dispatchEvent(myEvent);
           }
           else{
            const myEvent = new CustomEvent('fieldchange', {
                detail: {
                    addressType: this.addresslabel,
                    fieldName: event.target.name,
                    value: this.capitalize(this.template.querySelector('[name="' + event.target.name + '"]').value)
                }
            });
            this.dispatchEvent(myEvent);
        }
            // Calling parent using Event with data END
        
            
        }

    }

    eventKeyUpTextArea() {
        //var arr = $(this).val().split(' ');
        var arr = this.template.querySelector("lightning-textarea").value.split(' ');
        var result = '';
        for (var x = 0; x < arr.length; x++)
            result += arr[x].substring(0, 1).toUpperCase() + arr[x].substring(1) + ' ';
        this.template.querySelector("lightning-textarea").value = result.substring(0, result.length - 1);
    }

    addressChangeHandler(event) {
        this.searchAddressStr = this.template.querySelector('[name="inputAddress"]').value;
        let searchAddressStr = this.template.querySelector('[name="inputAddress"]').value;
        // console.log('Line 15 -> ',searchAddressStr);
        // console.log('Line 15 length -> ',searchAddressStr.length);

        if (searchAddressStr.length > 2) {
            this.findAddress(event, this.searchAddressStr);

        } else if (event.keyCode === 13) {
            // console.log('Line 16 -> On enter');
            this.findAddress(event, this.searchAddressStr);

        } else {
            this.addressResponseList = [];
            this.showAddresses = false;

            // const resBox = this.template.querySelector(".niManual");
            // resBox.innerHTML = '';
        }
    }

    demoTextarea() {
        // console.log('Line 155 textarea -> ',this.streetName);
    }

    // First method of searching address via loqate
    findAddress(event, searchAddressStr, SecondFind) {
        //debugger;
        // console.log('Line 67 finding address');
        //var Text = document.getElementById("searchBox2").value;
        

        var searchText = searchAddressStr;
        var availableopts = [];
        var myOrgBaseURL = window.location.origin;
        // console.log('searchText -> '+searchText);

        if (searchText === "") {
            showError("Please enter an address");
            return;
        }

        var Container = "";
        if (SecondFind !== undefined) {
            Container = SecondFind;
        }

        var Key = this.label.loqateKey,    //Key = $A.get("$Label.c.Loqate_key"),
            IsMiddleware = false,
            Origin = "",
            Countries = "GBR",
            Limit = "10",
            Language = "en-gb",
            url = 'https://services.postcodeanywhere.co.uk/Capture/Interactive/Find/v1.10/json3.ws';
        var params = '';
        params += "&Key=" + encodeURIComponent(Key);
        params += "&Text=" + encodeURIComponent(searchText);
        params += "&IsMiddleware=" + encodeURIComponent(IsMiddleware);
        params += "&Container=" + encodeURIComponent(Container);
        params += "&Origin=" + encodeURIComponent(Origin);
        params += "&Countries=" + encodeURIComponent(Countries);
        params += "&Limit=" + encodeURIComponent(Limit);
        params += "&Language=" + encodeURIComponent(Language);
        //params += "&Access-Control-Allow-Origin=" + "https://uat-thedisputeservice.cs87.force.com";
        params += "&Access-Control-Allow-Origin=" + myOrgBaseURL;

        var listOfResponse = [];
        var http = new XMLHttpRequest();
        http.open('POST', url, true);
        http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        //http.setRequestHeader('Access-Control-Allow-Origin', 'https://uat-thedisputeservice.cs87.force.com');
        http.setRequestHeader('Access-Control-Allow-Origin', myOrgBaseURL);
        http.onreadystatechange = () => {
            //console.log('@@http.status -->> '+http.status+url); 
            if (http.readyState == 4 && http.status == 200) {
                var response = JSON.parse(http.responseText);
                
                // console.log('@@ response -> '+JSON.stringify(response));
                if (response.Items.length == 1 && typeof (response.Items[0].Error) != "undefined") {
                    showError(response.Items[0].Description);
                    this.showAddresses = false;
                }
                else {
                    if (response.Items.length == 0) {
                        showError("Sorry, there were no results");
                        //reject("Sorry, there were no results");

                    } else {

                        // console.log('Line 159 response -> ',response.Items.length);
                        // console.log('Line 160 response -> ',JSON.stringify(response.Items[0]));

                        //console.log('Line 162 -> showAddresses -> ',this.showAddresses);



                        if (this.addressType === 'Chlid Addresses') {
                            for (var i = 0; i < response.Items.length; i++) {
                                // console.log('response 141 -> '+response.Items[i].Text);
                                // console.log('response 142 -> '+response.Items[i].Description);
                                // console.log('response 143 -> '+response.Items[i].Id);
                                // console.log('response 144 -> '+response.Items[i].Type);
                                if (response.Items[i].length > 1) {
                                    // console.log('response 170 -> Child nodes present');
                                }
                                var responseDetail = {
                                    "text": response.Items[i].Text,
                                    "description": response.Items[i].Description,
                                    "Id": response.Items[i].Id,
                                    "type": response.Items[i].Type
                                }

                                listOfResponse.push(responseDetail);

                            }

                        } else {
                            for (var i = 0; i < response.Items.length; i++) {
                                // console.log('response 141 -> '+response.Items[i].Text);
                                // console.log('response 142 -> '+response.Items[i].Description);
                                // console.log('response 143 -> '+response.Items[i].Id);
                                // console.log('response 144 -> '+response.Items[i].Type);
                                if (response.Items[i].length > 1) {
                                    // console.log('response 170 -> Child nodes present');
                                }
                                var responseDetail = {
                                    "text": response.Items[i].Text,
                                    "description": response.Items[i].Description,
                                    "Id": response.Items[i].Id,
                                    "type": response.Items[i].Type
                                }

                                listOfResponse.push(responseDetail);

                            }
                        }

                        // console.log('Line 213 -> ',this.showAddresses);
                        this.showAddresses = true;                            // Showing the picklist of addresses on HTML
                        this.addressResponseList = listOfResponse;            // Initializing the picklist values of addresses
                        // console.log('Line 215 -> ',JSON.stringify(this.addressResponseList));

                        //this.selectAddress(event,searchText);
                    }
                }
            }
        };
        //http.onerror = () => reject(http.statusText);
        http.send(params);

        // console.log('Line 222 -> ',lstTempResponse);

    }
    
    // Second method of searching address via loqate on span call
    handleAddressClick(event) {
        
        let currentSelectedAddressId = event.target.getAttribute('data-id');
        // console.log('Line 297 currentSelectedAddressId -> ',currentSelectedAddressId);

        this.addressResponseList.forEach(resp => {
            if (resp.Id == currentSelectedAddressId) {
                // console.log(`Line 298  ************* Found ************* -> ${resp.text} ${resp.description}`);
                this.template.querySelector('[name="inputAddress"]').value = resp.text + ' ' + resp.description;
            }
        });
        // console.log('Line 297 selected value -> ',currentSelectedAddressId);

        this.addressResponseList.forEach(currResponse => {
            if (currentSelectedAddressId == currResponse.Id) {
                // console.log('Line 276 currResponse -> ',JSON.stringify(currResponse));
                if (currResponse.description.includes('Addresses')) {
                    this.addressType = 'Chlid Addresses';
                    this.findAddress(event, this.searchAddressStr, currentSelectedAddressId);

                } else {
                    // console.log('Line 322 -> doesnt contains addresses');
                    this.retrieveAddress(event, currentSelectedAddressId);
                }
            }
        });

        
    }

    // Second method of searching address via loqate
    selectAddressHandler(event) {
        // console.log('Line 226 -> ');
        var selectedAddress = this.template.querySelector("[name='selectAddress']");
        // console.log('Line 228 selectedAddress -> ',selectedAddress.value);

        this.addressResponseList.forEach(currResponse => {
            if (selectedAddress.value == currResponse.Id) {
                // console.log('Line 276 currResponse -> ',JSON.stringify(currResponse));
                if (currResponse.description.includes('Addresses')) {
                    // console.log('Line 317 -> contains addresses');
                    this.addressType = 'Chlid Addresses';
                    this.findAddress(event, this.searchAddressStr, currResponse.Id);

                } else {
                    // console.log('Line 322 -> doesnt contains addresses');
                    this.retrieveAddress(event, currResponse.Id);
                }
            }
        });

    }

    // Third method of searching address via loqate
    retrieveAddress(event, Id) {
        // console.log(`Line 330 Key -> ${this.label.loqateKey} -> Id -> ${Id}`);
        var Field1Format = "";
        var url = 'https://services.postcodeanywhere.co.uk/Capture/Interactive/Retrieve/v1.00/json3.ws';
        var params = '';
        params += "&Key=" + encodeURIComponent(this.label.loqateKey);
        params += "&Id=" + encodeURIComponent(Id);
        params += "&Field1Format=" + encodeURIComponent(Field1Format);

        var http = new XMLHttpRequest();
        http.open('POST', url, true);
        http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        http.onreadystatechange = () => {
            if (http.readyState == 4 && http.status == 200) {
                var response = JSON.parse(http.responseText);

                if (response.Items.length == 1 && typeof (response.Items[0].Error) != "undefined") {
                    showError(response.Items[0].Description);

                } else {
                    if (response.Items.length == 0)
                        showError("Sorry, there were no results");
                    else {
                        // console.log('Line 357 api call success - '+JSON.stringify(response.Items[0]));
                        var addressline = '';
                        var addressline1 = '';
                        if (response.Items[0].Line1 != '') {
                            addressline1 = addressline + response.Items[0].Line1;
                        }
                        if (response.Items[0].Line2 != '') {
                            addressline = addressline + '\n' + response.Items[0].Line2;
                        }
                        if (response.Items[0].Line3 != '') {
                            addressline = addressline + '\n' + response.Items[0].Line3;
                        }

                        this.showSelectedAddresses = true;

                        // if(this.showSelectedAddresses){
                        //     this.isManualAddress = true;
                        // }

                        this.houseNo = addressline1;
                        this.streetName = addressline;
                        this.townCity = response.Items[0].City;
                        this.county = response.Items[0].Province;
                        this.postCode = response.Items[0].PostalCode;
                        this.BuildingName = this.BuildingName;
                        this.Locality = this.Locality;
                        if (!this.isHideCountry) {
                            this.country = response.Items[0].CountryName;
                        }
                        var returnAddress = {};
                        returnAddress.AddressLine = addressline;
                        //returnAddress.Street = response.Items[0].Line3;
                        returnAddress.houseNo = addressline1;
                        returnAddress.Street = addressline;
                        returnAddress.Town = response.Items[0].City;
                        returnAddress.County = response.Items[0].Province;
                        returnAddress.Postcode = response.Items[0].PostalCode;
                        
                        if (!this.isHideCountry) {
                            returnAddress.Country = response.Items[0].CountryName;
                        }
                        returnAddress.localAuthorityArea = response.Items[0].AdminAreaName;
                        if (response.Items[0].BuildingNumber == '') {
                            this.isHouse = true;
                            returnAddress.houseNo = response.Items[0].BuildingName;
                            this.houseNo= response.Items[0].BuildingName;

                        } else {
                            this.isHouse = true;
                            returnAddress.houseNo = response.Items[0].BuildingNumber;
                            this.houseNo= response.Items[0].BuildingNumber;
                        }

                        console.log('line 502', this.houseNo);
                        console.log('line 503', this.streetName);
                        console.log('line 504', this.townCity);
                        console.log('line 505', this.postCode);
                        console.log('line 506', this.BuildingName);
                        console.log('line 507', this.Locality);
                        // console.log('Line 434 -> from child ->  ',JSON.stringify(returnAddress));

                        // Calling parent using Event with data START
                        const myEvent = new CustomEvent('selectingaddress', {
                            detail: {
                                addressType: this.addresslabel,
                                addressObj: returnAddress
                            }
                        });
                        this.dispatchEvent(myEvent);
                        // Calling parent using Event with data END

                        // console.log('Line 445 -> from child ');

                        //  console.log(response.Items[0].Line3+' --<addressline-->>'+addressline); 
                        //  console.log('BuildingNumber-->>'+response.Items[0].BuildingNumber); 
                        //  console.log('BuildingName-->>'+response.Items[0].BuildingName); 
                        //  console.log('SubBuilding-->>'+response.Items[0].SubBuilding); 
                        //  console.log('Test record-->>'+response.Items[0].AdminAreaName);
                        /* if(arr.length > 5) {
                            var addressline = arr[arr.length-6] + ' \n ' +arr[arr.length-5];
                            component.set('v.AddressLine1',addressline);
                            
                        } else {
                             component.set('v.AddressLine1',arr[arr.length-5]);
                        } */
                        // alert( component.get('v.PostCode'));

                        // To include in the code
                        //var vx = component.get("v.method");
                        //$A.enqueueAction(vx);   

                        /*document.getElementById("output").style.display = "block";
                        document.getElementById("seperator").style.display = "block";
                        document.getElementById("manualAddress").style.display = "none";*/

                        this.showAddresses = false;
                    }
                }
            }
        }
        http.send(params);
    }

}