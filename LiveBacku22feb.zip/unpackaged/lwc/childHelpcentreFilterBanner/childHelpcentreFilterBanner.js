import { LightningElement, track, api } from 'lwc';

export default class childHelpcentreFilterBanner extends LightningElement {

    @track filterSelection = {customerType: 'Tenant', productType: 'Custodial',recordType:'FAQ'};

    @api tenantLabel;
    @api landlordLabel;
    @api agentLabel;
    @api custodialLabel;
    @api insuredLabel;
    @api filterbannerheading;
    @api selectproductlabel;
    @api custodialSummary;
    @api insuredSummary;

    connectedCallback() {        
        this.filterSelection.customerType = localStorage.getItem('customerType') || 'Tenant';
        this.filterSelection.productType = localStorage.getItem('productType') || 'Custodial';
        this.filterSelection.recordType = localStorage.getItem('recordType') || 'FAQ';
        console.log('customer type in child connected callback: '+this.filterSelection.customerType );
        

   }

    passCustomerTypeFilterToParent(inputevent){
        this.filterSelection = {customerType: inputevent.target.name, productType: this.filterSelection.productType,recordType:this.filterSelection.recordType};
        localStorage.setItem('customerType', inputevent.target.name);     
        // Dispatch a custom event to notify the parent of the new value
        const event = new CustomEvent('change', {
            detail: { filterSelection: this.filterSelection }
        });                
        this.dispatchEvent(event);           
      }   

      passProductTypeFilterToParent(inputevent) {
        this.filterSelection = {customerType: this.filterSelection.customerType, productType: inputevent.target.name,recordType:this.filterSelection.recordType};
        localStorage.setItem('productType', inputevent.target.name); 
        console.log('this.filterSelection: '+JSON.stringify(this.filterSelection));
        // Dispatch a custom event to notify the parent of the new value
        const event = new CustomEvent('change', {
            detail: { filterSelection: this.filterSelection }
        });       
        this.dispatchEvent(event);               
      }  

      get buttonClassCustodial() {
        return this.filterSelection.productType === 'Custodial' ? 'button-small active' : 'button-small';
    }
    
    get buttonClassInsured() {
        return this.filterSelection.productType === 'Insured' ? 'button-small active' : 'button-small';
    }


    get buttonClassTenant() {
        return this.filterSelection.customerType === 'Tenant' ? 'button-big active' : 'button-big';
    }
    
    get buttonClassLandlord() {
        return this.filterSelection.customerType === 'Landlord' ? 'button-big active' : 'button-big';
    }
    
    get buttonClassAgent() {
        return this.filterSelection.customerType === 'AGENT' ? 'button-big active' : 'button-big';
    }
}